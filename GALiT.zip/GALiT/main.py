from utils import *


args = load_args()
set_seed(args)
device = load_device(args)
data = load_data(args)
model = load_model(args, data)
train_model(args, device, data, model)
