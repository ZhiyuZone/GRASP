#-------------------- Cora --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset Cora --normalize_features --split public \
    --model GALiT --num_layers 8 --hidden_channels 256 --use_ln \
    --GALiT_prop_K 20 --GALiT_prop_alpha 0.05 --GALiT_func cos --GALiT_norm l2 --GALiT_alpha 0.35 --GALiT_beta 0.05 \
    --rounds 10 --epochs 500 --patience 100 --lr 0.001 --weight_decay 0.005 --dropout 0.5 \
    --evaluate_step 1 --evaluate_start 200 --display_step 10

#-------------------- CiteSeer --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset CiteSeer --normalize_features --split public \
    --model GALiT --num_layers 4 --hidden_channels 64 --use_ln \
    --GALiT_prop_K 10 --GALiT_prop_alpha 0.05 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.4 --GALiT_beta 0.3 \
    --rounds 10 --epochs 500 --patience 200 --lr 0.001 --weight_decay 1.0 --dropout 0.0 \
    --evaluate_step 1 --evaluate_start 50 --display_step 10

#-------------------- PubMed --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset PubMed --normalize_features --split public \
    --model GALiT --num_layers 3 --hidden_channels 64 --use_ln \
    --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 --GALiT_func cos --GALiT_norm fro --GALiT_alpha 0.65 --GALiT_beta 0.5 \
    --rounds 10 --epochs 500 --patience 100 --lr 0.001 --weight_decay 0.05 --dropout 0.3 \
    --evaluate_step 1 --evaluate_start 100 --display_step 10

#-------------------- Squirrel --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset Squirrel --split public \
    --model GALiT --num_layers 3 --hidden_channels 512 --use_ln \
    --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.2 --GALiT_beta 0.4 \
    --rounds 10 --epochs 200 --patience 100 --lr 0.001 --weight_decay 1.0 --dropout 0.5 \
    --evaluate_step 1 --evaluate_start 0 --display_step 10

#-------------------- Chameleon --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset Chameleon --split public \
    --model GALiT --num_layers 6 --hidden_channels 2048 --use_ln \
    --GALiT_prop_K 5 --GALiT_prop_alpha 0.0 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.25 --GALiT_beta 0.4 \
    --rounds 20 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.0001 --dropout 0.5 \
    --evaluate_step 1 --evaluate_start 0 --display_step 10

#-------------------- Actor --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset Actor --split public \
    --model GALiT --num_layers 1 --hidden_channels 1024 --use_ln --GALiT_transform \
    --GALiT_prop_K 0 --GALiT_prop_alpha 1.0 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.05 --GALiT_beta 0.25 \
    --rounds 10 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.0005 --dropout 0.9

#-------------------- ogbn-arxiv --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset ogbn-arxiv --split public \
    --model GALiT --num_layers 3 --hidden_channels 1024 --use_ln \
    --GALiT_prop_K 5 --GALiT_prop_alpha 0.05 --GALiT_func w-cos --GALiT_norm l2 --GALiT_alpha 0.15 --GALiT_beta 0.3 \
    --rounds 10 --epochs 2000 --patience 200 --lr 0.001 --weight_decay 0.0 --dropout 0.3 \
    --evaluate_step 1 --evaluate_start 500 --display_step 10

#-------------------- pokec --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset pokec --split full \
    --ratio_train 0.1 --ratio_val 0.1 --ratio_test 0.8 \
    --model GALiT --num_layers 1 --hidden_channels 64 --use_ln --GALiT_transform \
    --GALiT_prop_K 2 --GALiT_prop_alpha 0.0 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.45 --GALiT_beta 0.9 \
    --rounds 10 --epochs 30000 --patience 500 --lr 0.0005 --weight_decay 0.0 --dropout 0.15 \
    --evaluate_step 10 --evaluate_start 10000 --display_step 10

#-------------------- ogbn-products --------------------#
    python main.py \
    --seed 0 --device cuda:0 --setting transductive \
    --dataset ogbn-products --split full \
    --ratio_train 0.50 --ratio_val 0.25 --ratio_test 0.25 \
    --model GALiT --num_layers 1 --hidden_channels 1024 --use_ln --GALiT_transform \
    --GALiT_prop_K 5 --GALiT_prop_alpha 0.01 --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.4 --GALiT_beta 0.8 \
    --rounds 10 --epochs 1500 --patience 20 --lr 0.001 --weight_decay 0.000001 --dropout 0.3 \
    --batch_size 100000 --batch_size_val_test 612300 \
    --evaluate_step 10 --evaluate_start 0 --display_step 10

#-------------------- Cora --------------------#
    # MLP *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model MLP --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 300 --patience 100 --lr 0.005 --weight_decay 0.005 --dropout 0.7

    # GCN *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 300 --patience 100 --lr 0.01 --weight_decay 0.0005 --dropout 0.9

    # GAT *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model GAT --num_layers 2 --hidden_channels 8 \
        --GAT_heads 8 \
        --rounds 50 --epochs 500 --patience 100 --lr 0.01 --weight_decay 0.0005 --dropout 0.8

    # SAGE
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model SAGE --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.9

    # SGC
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model SGC --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 1.0 --weight_decay 0.0 --dropout 0.0

    # APPNP *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model APPNP --num_layers 10 --hidden_channels 64 \
        --APPNP_alpha 0.1 \
        --rounds 50 --epochs 500 --patience 100 --lr 0.01 --weight_decay 0.0005 --dropout 0.9

        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model APPNP --num_layers 10 --hidden_channels 64 \
        --APPNP_alpha 0.1 \
        --rounds 50 --epochs 500 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.9

    # TEST *
        # Split: (public) 20p / 500 / 1000 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --normalize_features --split public \
            --model TEST --num_layers 10 --hidden_channels 96 \
            --TEST_alpha 0.1 \
            --rounds 50 --epochs 500 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.75 \
            --evaluate_step 1 --evaluate_start 200 --display_step 10

        # Split: (public) 0.48 / 0.32 / 0.20 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --split geom-gcn --normalize_features \
            --model TEST --num_layers 10 --hidden_channels 128 \
            --TEST_alpha 0.15 \
            --lr 0.01 --weight_decay 0.0005 --dropout 0.55 \
            --rounds 50 --epochs 500 --patience 100 \
            --evaluate_step 1 --evaluate_start 200 --display_step 10

        # Split: (random) 0.60 / 0.20 / 0.20 *
            python main.py \
            --seed 0 --device cuda:4 --setting transductive \
            --dataset Cora --split full --normalize_features \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model TEST --num_layers 10 --hidden_channels 256 \
            --TEST_alpha 0.15 \
            --lr 0.01 --weight_decay 0.0005 --dropout 0.55 \
            --rounds 50 --epochs 500 --patience 100 \
            --evaluate_step 1 --evaluate_start 200 --display_step 10

        # Reconstruct
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset Cora --split public --normalize_features \
            --reconstruct --k 10 --loop \
            --model TEST --num_layers 10 --hidden_channels 256 \
            --TEST_alpha 0.1 \
            --lr 0.01 --weight_decay 0.0005 --dropout 0.55 \
            --rounds 10 --epochs 500 --patience 100 \
            --evaluate_step 1 --evaluate_start 200 --display_step 10

    # GraphSNE
        # Split: 20 / 500 / 1000 (fixed)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --normalize_features --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.1 --GraphSNE_filter_rounds 0 \
            --rounds 30 --epochs 500 --patience 200 --lr 0.005 --weight_decay 0.005 --dropout 0.75

        # Split: 0.48 / 0.32 / 0.20 (fixed) (filter train)
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset Cora --normalize_features --filter_edges --split geom-gcn \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.15 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 500 --patience 100 --lr 0.005 --weight_decay 0.00005 --dropout 0.2

        # Split: 0.60 / 0.20 / 0.20 (random) (filter train)
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset Cora --normalize_features --filter_edges --split full \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.1 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 500 --patience 100 --lr 0.005 --weight_decay 0.00005 --dropout 0.2

        # AD^(-1)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --normalize_features --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.1 \
            --rounds 10 --epochs 500 --patience 200 --lr 0.005 --weight_decay 0.001 --dropout 0.7

    # ExFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model ExFormer --num_layers 10 --hidden_channels 256 --use_ln \
        --ExFormer_heads 1 --ExFormer_func w-cos --ExFormer_norm fro --ExFormer_alpha 0.5 --ExFormer_beta 1.0 \
        --rounds 10 --epochs 500 --patience 100 --lr 0.001 --weight_decay 0.01 --dropout 0.5

    # GALiT
        # Split: (public) 20p / 500 / 1000 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --split public --normalize_features \
            --model GALiT --num_layers 8 --hidden_channels 256 --use_ln \
            --GALiT_prop_K 20 --GALiT_prop_alpha 0.05 \
            --GALiT_func w-cos --GALiT_norm l2 --GALiT_alpha 0.35 --GALiT_beta 0.05 \
            --lr 0.001 --weight_decay 0.005 --dropout 0.5 \
            --rounds 10 --epochs 500 --patience 100 \
            --evaluate_step 1 --evaluate_start 100 --display_step 10

        # Split: (public) 0.48 / 0.32 / 0.20
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora --split geom-gcn --normalize_features \
            --model GALiT --num_layers 8 --hidden_channels 64 --use_ln \
            --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 \
            --GALiT_func w-cos --GALiT_norm fro --GALiT_alpha 0.35 --GALiT_beta 0.1 \
            --lr 0.0005 --weight_decay 0.005 --dropout 0.5 \
            --rounds 20 --epochs 500 --patience 100 \
            --evaluate_step 1 --evaluate_start 0 --display_step 10

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Cora --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- CiteSeer --------------------#
    # MLP
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model MLP --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.1

    # GCN
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.5

    # GAT
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model GAT --num_layers 2 --hidden_channels 8 \
        --GAT_heads 8 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.1

    # SAGE
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model SAGE --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.01 --weight_decay 0.01 --dropout 0.1

    # SGC
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model SGC --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.01 --weight_decay 0.0 --dropout 0.0

    # APPNP
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model APPNP --num_layers 10 --hidden_channels 64 \
        --APPNP_alpha 0.1 \
        --rounds 30 --epochs 500 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.9

    # TEST
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --split public --normalize_features \
        --model TEST --num_layers 10 --hidden_channels 256 \
        --TEST_alpha 0.1 \
        --lr 0.01 --weight_decay 0.005 --dropout 0.0 \
        --rounds 50 --epochs 200 --patience 100

    # GraphSNE
        # Split: 20 / 500 / 1000 (fixed)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset CiteSeer --normalize_features --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 256 \
            --GraphSNE_alpha 0.1 \
            --rounds 30 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.0

        # Split: 0.48 / 0.32 / 0.20 (fixed) (filter train)
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset CiteSeer --normalize_features --filter_edges --split geom-gcn \
            --model GraphSNE --num_layers 10 --hidden_channels 64 \
            --GraphSNE_alpha 0.3 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 200 --patience 100 --lr 0.005 --weight_decay 0.00005 --dropout 0.5

        # Split: 0.60 / 0.20 / 0.20 (random) (filter train)
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset CiteSeer --normalize_features --filter_edges --split full \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model GraphSNE --num_layers 10 --hidden_channels 64 \
            --GraphSNE_alpha 0.2 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.00005 --dropout 0.4

        # D^(-1)A
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset CiteSeer --normalize_features --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 256 \
            --GraphSNE_alpha 0.1 \
            --rounds 20 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.01 --dropout 0.0

    # ExFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model ExFormer --num_layers 4 --hidden_channels 64 --use_ln \
        --ExFormer_heads 1 --ExFormer_func qk-cos --ExFormer_norm l2 --ExFormer_alpha 0.5 --ExFormer_beta 1.0 \
        --rounds 10 --epochs 500 --patience 100 --lr 0.001 --weight_decay 1.0 --dropout 0.0

    # GALiT
        # Split: (public) 20p / 500 / 1000
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset CiteSeer --split public --normalize_features \
            --model GALiT --num_layers 4 --hidden_channels 64 --use_ln \
            --GALiT_prop_K 20 --GALiT_prop_alpha 0.05 \
            --GALiT_func cos --GALiT_norm l2 --GALiT_alpha 0.4 --GALiT_beta 0.3 \
            --lr 0.001 --weight_decay 1.0 --dropout 0.0 \
            --rounds 10 --epochs 500 --patience 200 \
            --evaluate_step 1 --evaluate_start 50 --display_step 10

        # Split: (public) 0.48 / 0.32 / 0.20
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset CiteSeer --split geom-gcn --normalize_features \
            --model GALiT --num_layers 4 --hidden_channels 64 --use_ln \
            --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 \
            --GALiT_func m-cos --GALiT_norm fro --GALiT_alpha 0.45 --GALiT_beta 0.45 \
            --lr 0.001 --weight_decay 1.0 --dropout 0.0 \
            --rounds 20 --epochs 500 --patience 200 \
            --evaluate_step 1 --evaluate_start 0 --display_step 10

    # GALiTv2
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model GALiTv2 --num_layers 4 --hidden_channels 64 --use_ln \
        --GALiTv2_prop_K 20 --GALiTv2_prop_alpha 0.05 \
        --GALiTv2_func cos --GALiTv2_norm l2 --GALiTv2_alpha 0.4 --GALiTv2_beta 0.3 \
        --lr 0.001 --weight_decay 1.0 --dropout 0.0 \
        --rounds 10 --epochs 500 --patience 200 \
        --evaluate_step 1 --evaluate_start 50 --display_step 10

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset CiteSeer --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- PubMed --------------------#
    # MLP
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model MLP --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.3

    # GCN
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.1

    # GAT
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model GAT --num_layers 2 --hidden_channels 8 \
        --GAT_heads 8 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.001 --dropout 0.3

    # SAGE
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model SAGE --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGC
        python main.py \
        --seed 0 --device cuda:3 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model SGC --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.0 --dropout 0.0

    # APPNP
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model APPNP --num_layers 10 --hidden_channels 64 \
        --APPNP_alpha 0.1 \
        --rounds 30 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.0005 --dropout 0.0

    # TEST
        # Split: (public) 20p / 500 / 1000
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split public --normalize_features \
            --model TEST --num_layers 10 --hidden_channels 256 \
            --TEST_alpha 0.1 \
            --lr 0.01 --weight_decay 0.001 --dropout 0.5 \
            --rounds 50 --epochs 500 --patience 200 

        # Split: (random) 0.48 / 0.32 / 0.20 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split geom-gcn --normalize_features \
            --model TEST --num_layers 5 --hidden_channels 96 \
            --TEST_alpha 0.4 \
            --lr 0.1 --weight_decay 0.00001 --dropout 0.2 \
            --rounds 50 --epochs 500 --patience 100

            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split geom-gcn --normalize_features \
            --model TEST --num_layers 10 --hidden_channels 96 \
            --TEST_alpha 0.35 \
            --lr 0.1 --weight_decay 0.00001 --dropout 0.2 \
            --rounds 50 --epochs 500 --patience 100

        # Split: (random) 0.60 / 0.20 / 0.20 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split full --normalize_features \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model TEST --num_layers 10 --hidden_channels 96 \
            --TEST_alpha 0.4 \
            --lr 0.1 --weight_decay 0.000005 --dropout 0.25 \
            --rounds 50 --epochs 500 --patience 100

            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split full --normalize_features \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model TEST --num_layers 10 --hidden_channels 96 \
            --TEST_alpha 0.4 \
            --lr 0.1 --weight_decay 0.00001 --dropout 0.25 \
            --rounds 50 --epochs 500 --patience 100

        # D^(-1)A
            python main.py \
            --seed 0 --device cuda:1 --setting transductive \
            --dataset PubMed --split public \
            --model TEST --num_layers 10 --hidden_channels 256 \
            --TEST_alpha 0.1 \
            --rounds 10 --epochs 500 --patience 200 --lr 0.01 --weight_decay 0.005 --dropout 0.1

    # GraphSNE
        # Split: 20 / 500 / 1000 (fixed)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --normalize_features --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 256 \
            --GraphSNE_alpha 0.1 \
            --rounds 30 --epochs 500 --patience 200 --lr 0.01 --weight_decay 0.005 --dropout 0.5

        # Split: 0.48 / 0.32 / 0.20 (fixed) (filter train)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --normalize_features --filter_edges --split geom-gcn \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.3 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 500 --patience 100 --lr 0.1 --weight_decay 0.00001 --dropout 0.2

        # Split: 0.60 / 0.20 / 0.20 (random) (filter train)
            python main.py \
            --seed 0 --device cuda:3 --setting transductive \
            --dataset PubMed --normalize_features --filter_edges --split full \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model GraphSNE --num_layers 10 --hidden_channels 128 \
            --GraphSNE_alpha 0.3 --GraphSNE_filter_rounds 0 \
            --rounds 50 --epochs 500 --patience 100 --lr 0.1 --weight_decay 0.00001 --dropout 0.2

        # D^(-1)A
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split public \
            --model GraphSNE --num_layers 10 --hidden_channels 256 \
            --GraphSNE_alpha 0.1 \
            --rounds 10 --epochs 500 --patience 200 --lr 0.01 --weight_decay 0.005 --dropout 0.1

    # ExFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model ExFormer --num_layers 8 --hidden_channels 64 --use_ln \
        --ExFormer_heads 1 --ExFormer_func qk-cos --ExFormer_norm fro --ExFormer_alpha 0.5 --ExFormer_beta 0.95 \
        --rounds 10 --epochs 500 --patience 100 --lr 0.001 --weight_decay 1.0 --dropout 0.0

    # GALiT
        # Split: (public) 20p / 500 / 1000 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split public --normalize_features \
            --model GALiT --num_layers 3 --hidden_channels 64 --use_ln \
            --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 \
            --GALiT_func w2-cos --GALiT_norm fro --GALiT_alpha 0.65 --GALiT_beta 0.5 \
            --lr 0.001 --weight_decay 0.05 --dropout 0.3 \
            --rounds 10 --epochs 500 --patience 200 \
            --evaluate_step 1 --evaluate_start 200 --display_step 10

        # Split: (public) 0.48 / 0.32 / 0.20
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset PubMed --split geom-gcn --normalize_features \
            --model GALiT --num_layers 1 --hidden_channels 256 --use_ln \
            --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 \
            --GALiT_func qk-cos --GALiT_norm fro --GALiT_alpha 0.65 --GALiT_beta 0.5 \
            --lr 0.001 --weight_decay 0.05 --dropout 0.3 \
            --rounds 10 --epochs 500 --patience 200 

    # GALiTv2
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model GALiTv2 --num_layers 3 --hidden_channels 64 --use_ln \
        --GALiTv2_prop_K 10 --GALiTv2_prop_alpha 0.1 \
        --GALiTv2_func cos --GALiTv2_norm fro --GALiTv2_alpha 0.65 --GALiTv2_beta 0.5 \
        --lr 0.001 --weight_decay 0.05 --dropout 0.3 \
        --rounds 10 --epochs 500 --patience 200 \
        --evaluate_step 1 --evaluate_start 200 --display_step 10

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset PubMed --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- Cora-full --------------------#
    # MLP
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset Cora-full --split full \
        --ratio_train 0.7 --ratio_val 0.1 --ratio_test 0.2 \
        --model MLP --num_layers 2 --hidden_channels 256 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.01 --dropout 0.5

    # GCN
        python main.py \
        --seed 1 --device cuda:4 --setting transductive \
        --dataset Cora-full --split full \
        --ratio_train 0.7 --ratio_val 0.1 --ratio_test 0.2 \
        --model GCN --num_layers 2 --hidden_channels 256 \
        --rounds 10 --epochs 500 --patience 200 --lr 0.001 --weight_decay 0.01 --dropout 0.5

    # APPNP
        python main.py \
        --seed 1 --device cuda:0 --setting transductive \
        --dataset Cora-full --split full \
        --ratio_train 0.7 --ratio_val 0.1 --ratio_test 0.2 \
        --model APPNP --num_layers 10 --hidden_channels 256 \
        --APPNP_alpha 0.3 \
        --rounds 30 --epochs 500 --patience 100 --lr 0.001 --weight_decay 0.0001 --dropout 0.5

    # TEST
        # Split: full 0.70 / 0.10 / 0.20
            python main.py \
            --seed 1 --device cuda:0 --setting transductive \
            --dataset Cora-full --split full \
            --ratio_train 0.7 --ratio_val 0.1 --ratio_test 0.2 \
            --model TEST --num_layers 10 --hidden_channels 1024 \
            --TEST_alpha 0.3 \
            --lr 0.001 --weight_decay 0.0001 --dropout 0.3 \
            --rounds 10 --epochs 200 --patience 100

        # Split: full 0.60 / 0.20 / 0.20 *
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset Cora-full --split full \
            --ratio_train 0.6 --ratio_val 0.2 --ratio_test 0.2 \
            --model TEST --num_layers 5 --hidden_channels 1024 \
            --TEST_alpha 0.3 \
            --lr 0.001 --weight_decay 0.00005 --dropout 0.3 \
            --rounds 10 --epochs 100 --patience 50

    # GraphSNE
        python main.py \
        --seed 1 --device cuda:7 --setting transductive \
        --dataset Cora-full --split full \
        --ratio_train 0.7 --ratio_val 0.1 --ratio_test 0.2 \
        --model GraphSNE --num_layers 10 --hidden_channels 1024 \
        --GraphSNE_alpha 0.3 \
        --rounds 10 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.0001 --dropout 0.3

#-------------------- Squirrel --------------------#
    # TEST
        python main.py \
        --seed 0 --device cuda:5 --setting transductive \
        --dataset Squirrel --split public \
        --model TEST --num_layers 10 --hidden_channels 512 \
        --TEST_alpha 0.01 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.0 --dropout 0.0

        python main.py \
        --seed 0 --device cuda:1 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model TEST --num_layers 10 --hidden_channels 512 \
        --TEST_alpha 0.01 \
        --rounds 10 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.0 --dropout 0.0

    # GraphSNE
        python main.py \
        --seed 1 --device cuda:2 --setting transductive \
        --dataset Squirrel --split public \
        --model GraphSNE --num_layers 10 --hidden_channels 512 \
        --GraphSNE_alpha 0.01 --GraphSNE_filter_rounds 2 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.0 --dropout 0.0

    # GALiT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --split public \
        --model GALiT --num_layers 3 --hidden_channels 512 --use_ln \
        --GALiT_prop_K 10 --GALiT_prop_alpha 0.1 \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.2 --GALiT_beta 0.4 \
        --lr 0.001 --weight_decay 1.0 --dropout 0.5 \
        --rounds 10 --epochs 200 --patience 50 \
        --evaluate_step 1 --evaluate_start 0 --display_step 10

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Squirrel --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- Chameleon --------------------#
    # TEST
        python main.py \
        --seed 0 --device cuda:5 --setting transductive \
        --dataset Chameleon --split public \
        --model TEST --num_layers 5 --hidden_channels 2048 \
        --TEST_alpha 0.01 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.005 --weight_decay 0.0001 --dropout 0.0

    # GraphSNE
        python main.py \
        --seed 0 --device cuda:2 --setting transductive \
        --dataset Chameleon --split public \
        --model GraphSNE --num_layers 5 --hidden_channels 2048 \
        --GraphSNE_alpha 0.01 --GraphSNE_filter_rounds 0 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.005 --weight_decay 0.0001 --dropout 0.0

    # GALiT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --split public \
        --model GALiT --num_layers 6 --hidden_channels 2048 --use_ln \
        --GALiT_prop_K 5 --GALiT_prop_alpha 0.0 \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.25 --GALiT_beta 0.4 \
        --lr 0.001 --weight_decay 0.0001 --dropout 0.5 \
        --rounds 20 --epochs 200 --patience 100 \
        --evaluate_step 1 --evaluate_start 0 --display_step 10

        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --split public \
        --model GALiT --num_layers 6 --hidden_channels 2048 --use_ln \
        --GALiT_prop_K 4 --GALiT_prop_alpha 0.0 \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.25 --GALiT_beta 0.4 \
        --lr 0.001 --weight_decay 0.0001 --dropout 0.5 \
        --rounds 20 --epochs 200 --patience 100 \
        --evaluate_step 1 --evaluate_start 0 --display_step 10

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Chameleon --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- Actor --------------------#
    # MLP
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset Actor --split public \
        --model MLP --num_layers 2 --hidden_channels 128 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.001 --weight_decay 0.0001 --dropout 0.5 \
        --evaluate_start 100

    # GCN
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset Actor --split public \
        --model GCN --num_layers 2 --hidden_channels 128 \
        --rounds 50 --epochs 100 --patience 100 --lr 0.001 --weight_decay 0.0005 --dropout 0.5

    # TEST
        python main.py \
        --seed 1 --device cuda:0 --setting transductive \
        --dataset Actor --split public \
        --model TEST --num_layers 5 --hidden_channels 128 \
        --TEST_alpha 0.99 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.001 --weight_decay 0.005 --dropout 0.5

        python main.py \
        --seed 1 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model TEST --num_layers 5 --hidden_channels 128 \
        --TEST_alpha 0.9 \
        --rounds 30 --epochs 200 --patience 100 --lr 0.1 --weight_decay 0.0 --dropout 0.4

    # GALiT *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --split public \
        --model GALiT --num_layers 1 --hidden_channels 1024 --use_ln \
        --GALiT_prop_K 0 --GALiT_prop_alpha 1.0 --GALiT_use_trans --GALiT_use_activ \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.05 --GALiT_beta 0.25 \
        --lr 0.001 --weight_decay 0.0005 --dropout 0.9 \
        --rounds 10 --epochs 100 --patience 50

    # JKNet
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model JKNet --num_layers 2 --hidden_channels 64 \
        --JKNet_mode max --JKNet_alpha 0.1 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # H2GCN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model H2GCN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # GloGNN
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model GloGNN --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # ANS-GT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model ANS-GT --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NAGphormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model NAGphormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # NodeFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model NodeFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # DIFFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model DIFFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

    # SGFormer
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Actor --normalize_features --split public \
        --model SGFormer --num_layers 2 --hidden_channels 64 \
        --rounds 50 --epochs 200 --patience 100 --lr 0.01 --weight_decay 0.005 --dropout 0.5

#-------------------- Wisconsin --------------------#
    # TEST
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset Wisconsin --normalize_features --split public \
        --model TEST --num_layers 5 --hidden_channels 1024 \
        --TEST_alpha 0.99 \
        --rounds 10 --epochs 300 --patience 100 --lr 0.001 --weight_decay 0.0001 --dropout 0.3

    # GALiT
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset Wisconsin --split public \
        --model GALiT --num_layers 1 --hidden_channels 1024 --use_ln \
        --GALiT_prop_K 0 --GALiT_prop_alpha 1.0 \
        --GALiT_func qk-cos --GALiT_norm l2 --GALiT_alpha 0.5 --GALiT_beta 0.75 \
        --rounds 50 --epochs 500 --patience 100 --lr 0.005 --weight_decay 0.1 --dropout 0.3

#-------------------- ogbn-arxiv --------------------#
    # GCN
        python main.py \
        --seed 0 --device cuda:2 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model GCN --num_layers 3 --hidden_channels 256 \
        --rounds 5 --epochs 2000 --patience 200 --lr 0.005 --weight_decay 0.01 --dropout 0.5

    # APPNP
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model APPNP --num_layers 5 --hidden_channels 1024 \
        --APPNP_alpha 0.05 \
        --rounds 10 --epochs 3000 --patience 200 --lr 0.005 --weight_decay 0.0001 --dropout 0.0

    # TEST
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model TEST --num_layers 5 --hidden_channels 1024 \
        --TEST_alpha 0.05 \
        --rounds 20 --epochs 3000 --patience 200 --lr 0.005 --weight_decay 0.0001 --dropout 0.0 \
        --evaluate_step 1 --evaluate_start 1500 --display_step 10

    # GraphSNE
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model GraphSNE --num_layers 5 --hidden_channels 1024 \
        --GraphSNE_alpha 0.05 --GraphSNE_filter_rounds 0 \
        --rounds 10 --epochs 3000 --patience 200 --lr 0.005 --weight_decay 0.0001 --dropout 0.0

    # ExFormer
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model ExFormer --num_layers 3 --hidden_channels 1024 --use_ln \
        --ExFormer_heads 1 --ExFormer_func qk-cos --ExFormer_norm l2 --ExFormer_alpha 0.5 --ExFormer_beta 0.9 \
        --rounds 1 --epochs 100 --patience 100 --lr 0.005 --weight_decay 0.0001 --dropout 0.0 \
        --evaluate_step 1 --evaluate_start 100 --display_step 100

    # GALiT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-arxiv --split public \
        --model GALiT --num_layers 3 --hidden_channels 1024 --use_ln \
        --GALiT_prop_K 5 --GALiT_prop_alpha 0.05 --GALiT_func w-cos --GALiT_norm l2 --GALiT_alpha 0.15 --GALiT_beta 0.3 \
        --rounds 10 --epochs 2000 --patience 20 --lr 0.001 --weight_decay 0.0 --dropout 0.3 \
        --evaluate_step 10 --evaluate_start 500 --display_step 10

#-------------------- pokec --------------------#
    # TEST
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset pokec --split full \
        --ratio_train 0.1 --ratio_val 0.1 --ratio_test 0.8 \
        --model TEST --num_layers 10 --hidden_channels 1024 \
        --TEST_alpha 0.7 \
        --rounds 1 --epochs 3000 --patience 200 --lr 0.005 --weight_decay 0.0 --dropout 0.0 \
        --evaluate_step 1 --evaluate_start 0 --display_step 10

    # ExFormer
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset pokec --split full \
        --ratio_train 0.1 --ratio_val 0.1 --ratio_test 0.8 \
        --model ExFormer --num_layers 4 --hidden_channels 64 --use_ln \
        --ExFormer_heads 1 --ExFormer_func qk-cos --ExFormer_norm l2 --ExFormer_alpha 0.5 --ExFormer_beta 0.9 \
        --rounds 1 --epochs 100 --patience 100 --lr 0.0005 --weight_decay 0.0 --dropout 0.15 \
        --evaluate_step 1 --evaluate_start 100 --display_step 100

    # GALiT
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset pokec --split full \
        --ratio_train 0.1 --ratio_val 0.1 --ratio_test 0.8 \
        --model GALiT --num_layers 1 --hidden_channels 64 --use_ln \
        --GALiT_prop_K 2 --GALiT_prop_alpha 0.0 --GALiT_use_trans --GALiT_use_activ \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.45 --GALiT_beta 0.9 \
        --rounds 10 --epochs 30000 --patience 500 --lr 0.0005 --weight_decay 0.0 --dropout 0.15 \
        --evaluate_step 10 --evaluate_start 10000 --display_step 10

#-------------------- ogbn-products --------------------#
    # TEST
        # split: (random) 0.50 / 0.25 / 0.25
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset ogbn-products --split full \
            --ratio_train 0.50 --ratio_val 0.25 --ratio_test 0.25 \
            --model TEST --num_layers 5 --hidden_channels 1024 \
            --TEST_alpha 0.05 \
            --rounds 5 --epochs 5000 --patience 200 --lr 0.005 --weight_decay 0.00001 --dropout 0.0 \
            --evaluate_step 1 --evaluate_start 1000 --display_step 10

        # split: (public)
            python main.py \
            --seed 0 --device cuda:0 --setting transductive \
            --dataset ogbn-products --split public \
            --model TEST --num_layers 5 --hidden_channels 1024 \
            --TEST_alpha 0.1 \
            --rounds 10 --epochs 2000 --patience 20 --lr 0.005 --weight_decay 0.00001 --dropout 0.2 \
            --batch_size 100000 --batch_size_eval 612300 \
            --evaluate_step 10 --evaluate_start 500 --display_step 10

        # split: (random) 20p / 30p / remain *
            python main.py \
            --seed 0 --device cuda:7 --setting transductive \
            --dataset ogbn-products --split full \
            --ratio_train 0.0003838 --ratio_val 0.0005757 --ratio_test 0.9990405 \
            --model TEST --num_layers 10 --hidden_channels 256 \
            --TEST_alpha 0.01 \
            --lr 0.005 --weight_decay 0.00005 --dropout 0.3 \
            --rounds 200 --epochs 300 --patience 50 \
            --batch_size 10000 --batch_size_eval 612300 \
            --evaluate_step 1 --evaluate_start 0 --display_step 10

    # GALiT *
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-products --split full \
        --ratio_train 0.50 --ratio_val 0.25 --ratio_test 0.25 \
        --model GALiT --num_layers 1 --hidden_channels 1024 --use_ln \
        --GALiT_prop_K 5 --GALiT_prop_alpha 0.01 --GALiT_use_trans --GALiT_use_activ \
        --GALiT_func m-cos --GALiT_norm l2 --GALiT_alpha 0.4 --GALiT_beta 0.8 \
        --lr 0.001 --weight_decay 0.000001 --dropout 0.3 \
        --rounds 10 --epochs 500 --patience 50 \
        --batch_size 50000 --batch_size_eval 612300 \
        --evaluate_step 1 --evaluate_start 300 --display_step 10

        python main.py \
        --seed 0 --device cuda:4 --setting transductive \
        --dataset ogbn-products --split full \
        --ratio_train 0.50 --ratio_val 0.25 --ratio_test 0.25 \
        --model GALiT --num_layers 1 --hidden_channels 256 \
        --GALiT_prop_K 0 --GALiT_prop_alpha 1.0 \
        --GALiT_func cos --GALiT_norm l2 --GALiT_alpha 0.4 --GALiT_beta 0.8 \
        --lr 0.001 --weight_decay 0.0 --dropout 0.0 \
        --rounds 1 --epochs 100 --patience 100 \
        --batch_size 80000 --batch_size_eval 80000 \
        --evaluate_step 1 --evaluate_start 80 --display_step 10

#-------------------- ogbn-papers --------------------#
    # MLP
        python main.py \
        --seed 0 --device cuda:7 --setting transductive \
        --dataset ogbn-papers --split public \
        --model MLP --num_layers 2 --hidden_channels 128 \
        --rounds 1 --epochs 2000 --patience 200 --lr 0.005 --weight_decay 0.0001 --dropout 0.1 \
        --batch_size 1000000 --evaluate_step 5 --display_step 5

    # TEST
        python main.py \
        --seed 0 --device cuda:0 --setting transductive \
        --dataset ogbn-papers --split public \
        --model TEST --num_layers 1 --hidden_channels 128 \
        --TEST_alpha 0.05 \
        --rounds 1 --epochs 5000 --patience 200 --lr 0.001 --weight_decay 0.0 --dropout 0.0 \
        --batch_size 100000 --evaluate_step 1 --display_step 1
