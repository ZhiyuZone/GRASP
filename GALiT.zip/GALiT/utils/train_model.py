import torch
from tqdm import tqdm
from .load_args import print_info
from torch_geometric.nn import APPNP as APPNPConv
from torch_geometric.transforms import RandomNodeSplit


def train_model(args, device, data, model):
    device0 = torch.device('cpu')

    data_preprocess(args, device0, data)
    model.to(device)
    criterion = torch.nn.CrossEntropyLoss()
    a_best_test_acc_all = []
    l_best_test_acc_all = []

    for round in tqdm(range(1, args.rounds+1), desc='Training Rounds') if args.rounds > 1 else range(1, args.rounds+1):
        data_reset_split(args, device0, data, round)
        model.reset_parameters()
        optimizer = load_optimizer(args, model)

        '''
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer,
            step_size=args.lr_decay_step,
            gamma=args.lr_decay_factor)
        '''

        a_best_val_acc = float('-inf')
        l_best_val_loss = float('inf')
        a_patience = l_patience = args.patience

        for epoch in range(1, args.epochs+1) if args.rounds > 1 else tqdm(range(1, args.epochs+1), desc='Training Epochs'):
            model.train()
            if args.batch_size == 0:
                optimizer.zero_grad()
                if args.model in ('MLP',):
                    out = model(data.x)
                elif args.model in ('TEST',):
                    out = model(data.x_prop)
                elif args.model in ('GALiT', 'GALiTv2'):
                    out = model(data.x, data.x_prop)
                else:
                    out = model(data)
                loss = criterion(out[data.train_mask], data.y[data.train_mask])
                loss.backward()
                optimizer.step()

            else:
                if args.model in ('MLP',):
                    for batch in data.train_batches:
                        optimizer.zero_grad()
                        out = model(data.x[batch].to(device))
                        loss = criterion(out, data.y[batch].to(device))
                        loss.backward()
                        optimizer.step()
                elif args.model in ('TEST',):
                    for batch in data.train_batches:
                        optimizer.zero_grad()
                        out = model(data.x_prop[batch].to(device))
                        loss = criterion(out, data.y[batch].to(device))
                        loss.backward()
                        optimizer.step()
                elif args.model in ('GALiT', 'GALiTv2'):
                    for batch in data.train_batches:
                        optimizer.zero_grad()
                        out = model(data.x[batch].to(device), data.x_prop[batch].to(device))
                        loss = criterion(out, data.y[batch].to(device))
                        loss.backward()
                        optimizer.step()
                else:
                    raise ValueError('Unsupported model.')

            # scheduler.step()

            if epoch % args.evaluate_step == 0 and epoch >= args.evaluate_start:
                train_loss, val_loss, _, train_acc, val_acc, test_acc = evaluate(args, data, model, criterion)

                if args.rounds == 1 and epoch % args.display_step == 0:
                    tqdm.write(
                        f"Round: {round:03d}, "
                        f"Epoch: {epoch:05d} | "
                        f"Train Loss: {train_loss:.4f}, "
                        f"Val Loss: {val_loss:.4f} | "
                        f"Train Acc: {train_acc:.4f}, "
                        f"Val Acc: {val_acc:.4f}, "
                        f"Test Acc: {test_acc:.4f}"
                    )

                if val_acc > a_best_val_acc:
                    a_best_epoch = epoch
                    a_best_train_loss = train_loss
                    a_best_val_loss = val_loss
                    a_best_train_acc = train_acc
                    a_best_val_acc = val_acc
                    a_best_test_acc = test_acc
                    a_patience = args.patience
                    # torch.save(model.state_dict(), './result/model_best_acc.pth')
                else:
                    a_patience -= 1

                if val_loss < l_best_val_loss:
                    l_best_epoch = epoch
                    l_best_train_loss = train_loss
                    l_best_val_loss = val_loss
                    l_best_train_acc = train_acc
                    l_best_val_acc = val_acc
                    l_best_test_acc = test_acc
                    l_patience = args.patience
                    # torch.save(model.state_dict(), './result/model_best_loss.pth')
                else:
                    l_patience -= 1

                if a_patience <= 0 and l_patience <= 0 and epoch >= (args.epochs+1) // 2:
                    break

        a_best_test_acc_all.append(a_best_test_acc)
        l_best_test_acc_all.append(l_best_test_acc)

        tqdm.write(
            f"------------------------------------------------------"
            f"\n[Round {round:03d} Best (ac)] "
            f"Epoch: {a_best_epoch:05d} | "
            f"Train Loss: {a_best_train_loss:.4f}, "
            f"Val Loss: {a_best_val_loss:.4f} | "
            f"Train Acc: {a_best_train_acc:.4f}, "
            f"Val Acc: {a_best_val_acc:.4f}, "
            f"Test Acc: {a_best_test_acc:.4f}"

            f"\n[Round {round:03d} Best (ls)] "
            f"Epoch: {l_best_epoch:05d} | "
            f"Train Loss: {l_best_train_loss:.4f}, "
            f"Val Loss: {l_best_val_loss:.4f} | "
            f"Train Acc: {l_best_train_acc:.4f}, "
            f"Val Acc: {l_best_val_acc:.4f}, "
            f"Test Acc: {l_best_test_acc:.4f}\n"
            f"------------------------------------------------------"
        )

    if args.rounds > 1:
        a_best_test_acc_all = torch.tensor(a_best_test_acc_all) * 100
        l_best_test_acc_all = torch.tensor(l_best_test_acc_all) * 100
        a_best_test_acc_mean = a_best_test_acc_all.mean().item()
        l_best_test_acc_mean = l_best_test_acc_all.mean().item()
        a_best_test_acc_min = a_best_test_acc_all.min().item()
        l_best_test_acc_min = l_best_test_acc_all.min().item()
        a_best_test_acc_max = a_best_test_acc_all.max().item()
        l_best_test_acc_max = l_best_test_acc_all.max().item()
        a_best_test_acc_std = a_best_test_acc_all.std().item() if args.rounds > 1 else 0
        l_best_test_acc_std = l_best_test_acc_all.std().item() if args.rounds > 1 else 0

        print(
            f"------------------------------------------------------"
            f"\n[Best Test Acc (ac)] "
            f"{a_best_test_acc_mean:.2f} ± {a_best_test_acc_std:.2f} "
            f"(Min: {a_best_test_acc_min:.2f}, "
            f"Max: {a_best_test_acc_max:.2f})"

            f"\n[Best Test Acc (ls)] "
            f"{l_best_test_acc_mean:.2f} ± {l_best_test_acc_std:.2f} "
            f"(Min: {l_best_test_acc_min:.2f}, "
            f"Max: {l_best_test_acc_max:.2f})\n"
            f"------------------------------------------------------"
        )

    print_info(args)


def data_preprocess(args, device, data):
    if args.dataset in ('Cora', 'CiteSeer', 'PubMed', 'Cora-full', 
                        'ogbn-arxiv', 
                        'Squirrel', 'Chameleon', 'Actor', 
                        'Cornell', 'Wisconsin', 'Texas'):
        data.to(device)

    if args.dataset in ('Cora', 'CiteSeer', 'PubMed', 'Cora-full', 
                        'ogbn-arxiv', 'ogbn-products', 
                        'Squirrel', 'Chameleon', 'Actor', 
                        'Cornell', 'Wisconsin', 'Texas', 
                        'pokec'):
        if args.model == 'TEST':
            prop = APPNPConv(K=args.num_layers, alpha=args.TEST_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)
        elif args.model == 'GALiT':
            prop = APPNPConv(K=args.GALiT_prop_K, alpha=args.GALiT_prop_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)
        elif args.model == 'GALiTv2':
            prop = APPNPConv(K=args.GALiTv2_prop_K, alpha=args.GALiTv2_prop_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)

    if args.dataset in ('ogbn-products', 'pokec'):
        data.to(device)

    data.edge_index_raw = data.edge_index


def data_reset_split(args, device, data, round):
    def create_batches(indices, batch_size):
        return [indices[i: i+batch_size] for i in range(0, len(indices), batch_size)]

    if args.split == 'public':
        if args.dataset in ('Squirrel', 'Chameleon', 'Actor', 
                            'Cornell', 'Wisconsin', 'Texas'):
            index = (round - 1) % 10
            data.train_mask = data.train_masks[index]
            data.val_mask = data.val_masks[index]
            data.test_mask = data.test_masks[index]

    elif args.split == 'geom-gcn':
        if args.dataset in ('Cora', 'CiteSeer', 'PubMed'):
            index = (round - 1) % 10
            data.train_mask = data.train_masks[index]
            data.val_mask = data.val_masks[index]
            data.test_mask = data.test_masks[index]

    elif args.split == 'random':
        transform = RandomNodeSplit(split='random', 
                                    num_train_per_class=args.num_train_per_class, 
                                    num_val=args.num_val, 
                                    num_test=args.num_test)
        transform(data)
        data.to(device)

    elif args.split == 'full':
        transform = RandomNodeSplit(split='train_rest', 
                                    num_val=args.ratio_val, 
                                    num_test=args.ratio_test)
        transform(data)
        data.to(device)

    if args.batch_size > 0:
        train_indices = data.train_mask.nonzero(as_tuple=False).view(-1)
        val_indices = data.val_mask.nonzero(as_tuple=False).view(-1)
        test_indices = data.test_mask.nonzero(as_tuple=False).view(-1)
        data.train_batches = create_batches(train_indices, args.batch_size)
        data.train_batches_eval = create_batches(train_indices, args.batch_size_eval)
        data.val_batches_eval = create_batches(val_indices, args.batch_size_eval)
        data.test_batches_eval = create_batches(test_indices, args.batch_size_eval)

    if args.filter_edges:
        edge_index, train_mask, y = data.edge_index_raw, data.train_mask, data.y
        not_in_train = ~train_mask[edge_index[0]] | ~train_mask[edge_index[1]]
        same_label_in_train = (y[edge_index[0]] == y[edge_index[1]]) & \
                              train_mask[edge_index[0]] & train_mask[edge_index[1]]
        mask = not_in_train | same_label_in_train
        data.edge_index = edge_index[:, mask]

        if args.model == 'TEST':
            prop = APPNPConv(K=args.num_layers, alpha=args.TEST_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)
        elif args.model == 'GALiT':
            prop = APPNPConv(K=args.GALiT_prop_K, alpha=args.GALiT_prop_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)
        elif args.model == 'GALiTv2':
            prop = APPNPConv(K=args.GALiTv2_prop_K, alpha=args.GALiTv2_prop_alpha).to(data.x.device)
            data.x_prop = prop(data.x, data.edge_index)


def load_optimizer(args, model):
    if args.model in ('MLP', 'GCN', 'GAT', 'SAGE'):
        optimizer = torch.optim.Adam([
            {'params': model.conv1.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.conv2.parameters(), 'weight_decay': 0.0}, 
            {'params': model.ln1.parameters(), 'weight_decay': 0.0}, 
            {'params': model.ln2.parameters(), 'weight_decay': 0.0}], 
            lr=args.lr)

    elif args.model in ('APPNP', 'TEST', 'GraphSNE'):
        optimizer = torch.optim.Adam([
            {'params': model.lin1.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.lin2.parameters(), 'weight_decay': 0.0}], 
            lr=args.lr)

    elif args.model in ('ExFormer',):
        optimizer = torch.optim.Adam([
            {'params': model.fc1.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.fc2.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.ln1.parameters(), 'weight_decay': 0.0}, 
            {'params': model.ln2.parameters(), 'weight_decay': 0.0}, 
            {'params': model.tfs.parameters(), 'weight_decay': args.weight_decay}], 
            lr=args.lr)

    elif args.model in ('GALiT', 'GALiTv2'):
        optimizer = torch.optim.Adam([
            {'params': model.fc1.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.fc2.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.ln1.parameters(), 'weight_decay': 0.0}, 
            {'params': model.ln2.parameters(), 'weight_decay': 0.0}, 
            {'params': model.tfs.parameters(), 'weight_decay': args.weight_decay}, 
            {'params': model.fcs.parameters(), 'weight_decay': args.weight_decay}], 
            lr=args.lr)

    else:
        optimizer = torch.optim.Adam(
            model.parameters(), 
            weight_decay=args.weight_decay, 
            lr=args.lr)

    return optimizer


@torch.no_grad()
def evaluate(args, data, model, criterion):
    model.eval()
    loss_ls, acc_ls = [], []

    if args.batch_size == 0:
        if args.model in ('MLP',):
            out = model(data.x)
        elif args.model in ('TEST',):
            out = model(data.x_prop)
        elif args.model in ('GALiT', 'GALiTv2'):
            out = model(data.x, data.x_prop)
        else:
            out = model(data)
        pred = out.argmax(dim=1)
        for mask in (data.train_mask, data.val_mask, data.test_mask):
            loss_ls.append(criterion(out[mask], data.y[mask]).item())
            acc_ls.append(pred[mask].eq(data.y[mask]).sum().item() / mask.sum().item())

    else:
        train_loss = val_loss = test_loss = 0.0
        train_acc_num = val_acc_num = test_acc_num = 0

        for batch in data.train_batches_eval:
            y_batch = data.y[batch]
            if args.model in ('MLP',):
                out = model(data.x[batch])
            elif args.model in ('TEST',):
                out = model(data.x_prop[batch])
            elif args.model in ('GALiT', 'GALiTv2'):
                out = model(data.x[batch], data.x_prop[batch])
            loss = criterion(out, y_batch)
            train_loss += loss.item()
            train_acc_num += (out.argmax(dim=1).eq(y_batch)).sum().item()
        loss_ls.append(train_loss / len(data.train_batches_eval))
        acc_ls.append(train_acc_num / data.train_mask.sum().item())

        for batch in data.val_batches_eval:
            y_batch = data.y[batch]
            if args.model in ('MLP',):
                out = model(data.x[batch])
            elif args.model in ('TEST',):
                out = model(data.x_prop[batch])
            elif args.model in ('GALiT', 'GALiTv2'):
                out = model(data.x[batch], data.x_prop[batch])
            loss = criterion(out, y_batch)
            val_loss += loss.item()
            val_acc_num += (out.argmax(dim=1).eq(y_batch)).sum().item()
        loss_ls.append(val_loss / len(data.val_batches_eval))
        acc_ls.append(val_acc_num / data.val_mask.sum().item())

        for batch in data.test_batches_eval:
            y_batch = data.y[batch]
            if args.model in ('MLP',):
                out = model(data.x[batch])
            elif args.model in ('TEST',):
                out = model(data.x_prop[batch])
            elif args.model in ('GALiT', 'GALiTv2'):
                out = model(data.x[batch], data.x_prop[batch])
            loss = criterion(out, y_batch)
            test_loss += loss.item()
            test_acc_num += (out.argmax(dim=1).eq(y_batch)).sum().item()
        loss_ls.append(test_loss / len(data.test_batches_eval))
        acc_ls.append(test_acc_num / data.test_mask.sum().item())

    return loss_ls + acc_ls


'''
def filter_edges(out, data, similarity='cosine', threshold_ratio=0.001, sigma=1.0):
    def gaussian_similarity(a, b, sigma=1.0):
        dist = torch.norm(a - b, dim=1)
        return torch.exp(-dist ** 2 / (2 * sigma ** 2))

    out = F.softmax(out, dim=1)
    edge_features_start = out[data.edge_index_raw[0]]
    edge_features_end = out[data.edge_index_raw[1]]

    if similarity == 'cosine':
        edge_similarities = F.cosine_similarity(edge_features_start, edge_features_end, dim=1)
    elif similarity == 'gaussian':
        edge_similarities = gaussian_similarity(edge_features_start, edge_features_end, sigma=sigma)
    elif similarity == 'label':
        predicted_labels_start = torch.argmax(edge_features_start, dim=1)
        predicted_labels_end = torch.argmax(edge_features_end, dim=1)
    else:
        raise ValueError("Unsupported similarity measure. Choose 'cosine', 'gaussian', or 'label'.")

    if similarity == 'label':
        mask = predicted_labels_start == predicted_labels_end
    else:
        threshold = torch.quantile(edge_similarities, threshold_ratio)
        mask = edge_similarities >= threshold

    train_mask_start = data.train_mask[data.edge_index_raw[0]]
    train_mask_end = data.train_mask[data.edge_index_raw[1]]
    train_mask_edge = train_mask_start & train_mask_end

    label_start = data.y[data.edge_index_raw[0]]
    label_end = data.y[data.edge_index_raw[1]]
    label_mask_edge = label_start == label_end

    mask = mask | (train_mask_edge & label_mask_edge)

    data.edge_index = data.edge_index_raw[:, mask]

    not_in_train_or_val = ~(data.train_mask[data.edge_index_raw[0]] | data.train_mask[data.edge_index_raw[1]] | 
                            data.val_mask[data.edge_index_raw[0]] | data.val_mask[data.edge_index_raw[1]])
    mask = mask | not_in_train_or_val

    not_in_train = ~(data.train_mask[data.edge_index_raw[0]] | data.train_mask[data.edge_index_raw[1]])
    mask = mask | not_in_train
'''
