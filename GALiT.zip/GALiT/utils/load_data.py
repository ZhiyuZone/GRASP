from data import *


def load_data(args, analysis=True):
    dataset_dict = {
        'Cora': load_Cora,
        'CiteSeer': load_CiteSeer,
        'PubMed': load_PubMed,
        'Cora-full': load_Cora_full,

        'ogbn-arxiv': load_ogbn_arxiv,
        'ogbn-products': load_ogbn_products,
        'ogbn-papers': load_ogbn_papers,

        'Squirrel': load_Squirrel,
        'Chameleon': load_Chameleon,
        'Actor': load_Actor,

        'Cornell': load_Cornell,
        'Wisconsin': load_Wisconsin,
        'Texas': load_Texas,

        'pokec': load_pokec,

        'ogbn-mag': load_ogbn_mag,
        'ogbn-proteins': load_ogbn_proteins,
        'snap-patents': load_snap_patents,
    }

    dataset = dataset_dict[args.dataset]
    data = dataset(args, analysis=analysis)
    return data
