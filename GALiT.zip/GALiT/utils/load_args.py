import argparse


def load_args():
    parser = argparse.ArgumentParser()

    # ----------Base----------
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--device', type=str, default='cpu')

    # ----------Data----------
    parser.add_argument('--root', type=str, default='./data/raw/')
    parser.add_argument('--dataset', type=str, default='Cora', 
                        choices=('Cora', 'CiteSeer', 'PubMed', 'Cora-full', 
                                 'ogbn-arxiv', 'ogbn-products', 'ogbn-papers', 
                                 'Squirrel', 'Chameleon', 'Actor', 
                                 'Cornell', 'Wisconsin', 'Texas', 
                                 'pokec', 
                                 'ogbn-mag', 'ogbn-proteins', 'snap-patents'))
    parser.add_argument('--normalize_features', action='store_true')
    parser.add_argument('--filter_edges', action='store_true')
    parser.add_argument('--setting', type=str, default='transductive', 
                        choices=('transductive', 'inductive'))
    parser.add_argument('--split', type=str, default='public', 
                        choices=('public', 'public-gat', 'geom-gcn', 
                                 'random', 'full'))
    # split: random
    parser.add_argument('--num_train_per_class', type=int, default=20)
    parser.add_argument('--num_val', type=int, default=500)
    parser.add_argument('--num_test', type=int, default=1000)
    # split: full
    parser.add_argument('--ratio_train', type=float, default=0.48)
    parser.add_argument('--ratio_val', type=float, default=0.32)
    parser.add_argument('--ratio_test', type=float, default=0.20)

    # ----------Model----------
    parser.add_argument('--model', type=str, default='GCN', 
                        choices=('MLP', 'GCN', 'GAT', 'SAGE', 'SGC', 'JKNet', 
                                 'APPNP', 'TEST', 'GraphSNE', 
                                 'DIFFormer', 'ExFormer', 'GALiT', 'GALiTv2'))
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--hidden_channels', type=int, default=64)
    parser.add_argument('--use_ln', action='store_true')
    # model: GAT
    parser.add_argument('--GAT_heads', type=int, default=8)
    # model: APPNP
    parser.add_argument('--APPNP_alpha', type=float, default=0.1)
    # model: TEST
    parser.add_argument('--TEST_alpha', type=float, default=0.1)
    # model: GraphSNE
    parser.add_argument('--GraphSNE_alpha', type=float, default=0.1)
    parser.add_argument('--GraphSNE_filter_rounds', type=int, default=0)
    # model: DIFFormer
    parser.add_argument('--DIFFormer_alpha', type=float, default=0.5)
    # model: ExFormer
    parser.add_argument('--ExFormer_heads', type=int, default=1)
    parser.add_argument('--ExFormer_transform', action='store_true')
    parser.add_argument('--ExFormer_func', type=str, default='w-cos', 
                        choices=('cos', 'w-cos', 'm-cos', 'qk-cos'))
    parser.add_argument('--ExFormer_norm', type=str, default='l2', 
                        choices=('l2', 'fro'))
    parser.add_argument('--ExFormer_alpha', type=float, default=0.5)
    parser.add_argument('--ExFormer_beta', type=float, default=1.0)
    # model: GALiT
    parser.add_argument('--GALiT_prop_K', type=int, default=10)
    parser.add_argument('--GALiT_prop_alpha', type=float, default=0.1)
    parser.add_argument('--GALiT_use_trans', action='store_true')
    parser.add_argument('--GALiT_use_activ', action='store_true')
    parser.add_argument('--GALiT_func', type=str, default='m-cos', 
                        choices=('cos', 'w-cos', 'w2-cos', 'm-cos', 'm2-cos'))
    parser.add_argument('--GALiT_norm', type=str, default='l2', 
                        choices=('none', 'l2', 'fro'))
    parser.add_argument('--GALiT_alpha', type=float, default=0.5)
    parser.add_argument('--GALiT_beta', type=float, default=0.5)
    # model: GALiTv2
    parser.add_argument('--GALiTv2_prop_K', type=int, default=10)
    parser.add_argument('--GALiTv2_prop_alpha', type=float, default=0.1)
    parser.add_argument('--GALiTv2_use_trans', action='store_true')
    parser.add_argument('--GALiTv2_use_activ', action='store_true')
    parser.add_argument('--GALiTv2_func', type=str, default='m-cos',
                        choices=('cos', 'w-cos', 'm-cos', 'qk-cos'))
    parser.add_argument('--GALiTv2_norm', type=str, default='l2',
                        choices=('l2', 'fro'))
    parser.add_argument('--GALiTv2_alpha', type=float, default=0.5)
    parser.add_argument('--GALiTv2_beta', type=float, default=0.5)

    # ----------Train----------
    parser.add_argument('--batch_size', type=int, default=0)
    parser.add_argument('--batch_size_eval', type=int, default=1000000)
    parser.add_argument('--rounds', type=int, default=10)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--patience', type=int, default=100)
    parser.add_argument('--lr_decay_step', type=int, default=1000)
    parser.add_argument('--lr_decay_factor', type=float, default=1.0)
    # core params
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--weight_decay', type=float, default=0.0005)
    parser.add_argument('--dropout', type=float, default=0.5)

    # ----------Reconstruct----------
    parser.add_argument('--reconstruct', action='store_true')
    parser.add_argument('--k', type=int, default=10)
    parser.add_argument('--loop', action='store_true')
    parser.add_argument('--cosine', action='store_true')

    # ----------Display----------
    parser.add_argument('--evaluate_step', type=int, default=1)
    parser.add_argument('--evaluate_start', type=int, default=0)
    parser.add_argument('--display_step', type=int, default=10)

    args = parser.parse_args()
    print_info(args)
    return args


def print_info(args):
    print('-------------------------Info-------------------------')
    print(f"[Basic Params] "
          f"model: {args.model}   "
          f"data: {args.dataset}   "
          f"setting: {args.setting}\n"
          f"               "
          f"split: {args.split}   "
          f"norm_feat: {args.normalize_features}   "
          f"filter_edge: {args.filter_edges}\n"
          f"[Train Params] "
          f"seed: {args.seed}   "
          f"batch_size: {args.batch_size}   "
          f"epochs: {args.epochs}   "
          f"patience: {args.patience}\n"
          f"               "
          f"lr: {args.lr}   "
          f"weight_decay: {args.weight_decay}   "
          f"dropout: {args.dropout}\n"
          f"[Model Params] "
          f"num_layers: {args.num_layers}   "
          f"hidden_channels: {args.hidden_channels}   "
          f"use_ln: {args.use_ln}")
    if args.model == 'GAT':
        print(f"               "
              f"heads: {args.GAT_heads}")
    elif args.model == 'APPNP':
        print(f"               "
              f"alpha: {args.APPNP_alpha}")
    elif args.model == 'TEST':
        print(f"               "
              f"alpha: {args.TEST_alpha}")
    elif args.model == 'GraphSNE':
        print(f"               "
              f"alpha: {args.GraphSNE_alpha}   "
              f"filter_rounds: {args.GraphSNE_filter_rounds}")
    elif args.model == 'DIFFormer':
        print(f"               "
              f"alpha: {args.DIFFormer_alpha}")
    elif args.model == 'ExFormer':
        print(f"               "
              f"heads: {args.ExFormer_heads}   "
              f"transform: {args.ExFormer_transform}   "
              f"func: {args.ExFormer_func}   "
              f"norm: {args.ExFormer_norm}   "
              f"alpha: {args.ExFormer_alpha}   "
              f"beta: {args.ExFormer_beta}")
    elif args.model == 'GALiT':
        print(f"               "
              f"prop_K: {args.GALiT_prop_K}   "
              f"prop_alpha: {args.GALiT_prop_alpha}   "
              f"use_trans: {args.GALiT_use_trans}   "
              f"use_activ: {args.GALiT_use_activ}\n"
              f"               "
              f"func: {args.GALiT_func}   "
              f"norm: {args.GALiT_norm}   "
              f"alpha: {args.GALiT_alpha}   "
              f"beta: {args.GALiT_beta}")
    elif args.model == 'GALiTv2':
        print(f"               "
              f"prop_K: {args.GALiTv2_prop_K}   "
              f"prop_alpha: {args.GALiTv2_prop_alpha}   "
              f"use_trans: {args.GALiTv2_use_trans}   "
              f"use_activ: {args.GALiTv2_use_activ}\n"
              f"               "
              f"func: {args.GALiTv2_func}   "
              f"norm: {args.GALiTv2_norm}   "
              f"alpha: {args.GALiTv2_alpha}   "
              f"beta: {args.GALiTv2_beta}")
    print('------------------------------------------------------')
