import torch
import random
import numpy as np


def set_seed(args):
    seed = args.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False  # False for repro
    torch.backends.cudnn.deterministic = True  # True for repro


def load_device(args):
    try:
        device = torch.device(args.device)
    except:
        device = torch.device('cpu')
    print(f'[Device] {device}')
    return device
