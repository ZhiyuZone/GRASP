from model import *


def load_model(args, data):
    if args.model == 'MLP':
        model = MLP(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout
        )

    elif args.model == 'GCN':
        model = GCN(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout
        )

    elif args.model == 'GAT':
        model = GAT(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout,
            heads=args.GAT_heads
        )

    elif args.model == 'SAGE':
        model = SAGE(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout
        )

    elif args.model == 'SGC':
        model = SGC(
            in_channels=data.num_features,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            dropout=args.dropout
        )

    elif args.model == 'JKNet':
        model = JKNet(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            dropout=args.dropout
        )

    elif args.model == 'APPNP':
        model = APPNP(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            dropout=args.dropout,
            alpha=args.APPNP_alpha
        )

    elif args.model == 'TEST':
        model = TEST(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            dropout=args.dropout
        )

    elif args.model == 'GraphSNE':
        model = GraphSNE(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            dropout=args.dropout,
            alpha=args.GraphSNE_alpha
        )

    elif args.model == 'DIFFormer':
        model = DIFFormer(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            dropout=args.dropout,
            alpha=args.DIFFormer_alpha
        )

    elif args.model == 'ExFormer':
        model = ExFormer(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout,
            heads=args.ExFormer_heads,
            transform=args.ExFormer_transform,
            func=args.ExFormer_func,
            norm=args.ExFormer_norm,
            alpha=args.ExFormer_alpha,
            beta=args.ExFormer_beta
        )

    elif args.model == 'GALiT':
        model = GALiT(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout,
            use_trans=args.GALiT_use_trans,
            use_activ=args.GALiT_use_activ,
            func=args.GALiT_func,
            norm=args.GALiT_norm,
            alpha=args.GALiT_alpha,
            beta=args.GALiT_beta
        )

    elif args.model == 'GALiTv2':
        model = GALiTv2(
            in_channels=data.num_features,
            hidden_channels=args.hidden_channels,
            out_channels=data.num_classes,
            num_layers=args.num_layers,
            use_ln=args.use_ln,
            dropout=args.dropout,
            use_trans=args.GALiTv2_use_trans,
            use_activ=args.GALiTv2_use_activ,
            func=args.GALiTv2_func,
            norm=args.GALiTv2_norm,
            alpha=args.GALiTv2_alpha,
            beta=args.GALiTv2_beta
        )

    return model
