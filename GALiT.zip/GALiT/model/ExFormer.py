import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_sparse import matmul


def transformer_layer(Q, K, V):
    # Q: [n, h, m]    K: [l, h, m]    V: [l, h, d]    O: [n, h, d]

    K_V_sum = torch.einsum("lhm,lhd->hmd", K, V)  # [h, m, d]
    Q_K_V_sum = torch.einsum("nhm,hmd->nhd", Q, K_V_sum)  # [n, h, d]
    V_sum = V.sum(dim=0, keepdim=True)  # [1, h, d]
    att_value = Q_K_V_sum + V_sum  # [n, h, d]

    K_sum = K.sum(dim=0)  # [h, m]
    Q_K_sum = torch.einsum("nhm,hm->nh", Q, K_sum).unsqueeze(-1)  # [n, h, 1]
    att_norm = Q_K_sum + K.shape[0]  # [n, h, 1]

    O = att_value / att_norm  # [n, h, d]
    return O


class TransformerLayer(nn.Module):
    def __init__(self, channels, heads=1, func='qk-cos', norm='l2'):
        super(TransformerLayer, self).__init__()

        '''
        if func not in ('cos', 'w-cos', 'm-cos', 'qk-cos'):
            raise ValueError(f'Invalid func: {func}')
        if norm not in ('l2', 'fro'):
            raise ValueError(f'Invalid norm: {norm}')

        self.Wq = nn.Linear(channels, heads * channels)
        self.Wk = nn.Linear(channels, heads * channels)
        self.Ws = nn.Parameter(torch.ones(heads, channels))
        '''

        if norm not in ('l2', 'fro'):
            raise ValueError(f'Invalid norm: {norm}')

        if func == 'cos':
            pass
        elif func == 'w-cos':
            self.Ws = nn.Parameter(torch.ones(heads, channels))
            # self.Ws_bias = nn.Parameter(torch.zeros(heads, channels))
        elif func == 'm-cos':
            self.Wm = nn.Linear(channels, heads * channels)
        elif func == 'qk-cos':
            self.Wq = nn.Linear(channels, heads * channels)
            self.Wk = nn.Linear(channels, heads * channels)
        else:
            raise ValueError(f'Invalid func: {func}')

        self.channels = channels
        self.heads = heads
        self.func = func
        self.norm = norm

    def reset_parameters(self):
        '''
        self.Wq.reset_parameters()
        self.Wk.reset_parameters()
        nn.init.ones_(self.Ws)
        '''
        if self.func == 'w-cos':
            nn.init.ones_(self.Ws)
            # nn.init.zeros_(self.Ws_bias)
        elif self.func == 'm-cos':
            self.Wm.reset_parameters()
        elif self.func == 'qk-cos':
            self.Wq.reset_parameters()
            self.Wk.reset_parameters()

    def forward(self, x1, x2, get_attention=False):
        # x1: [n, d]    x2: [l, d]    adj: [n, n]    O: [n, d]

        if self.func == 'cos':
            Q = x1.unsqueeze(1)  # [n, 1, m]
            K = x2.unsqueeze(1)  # [l, 1, m]

        elif self.func == 'w-cos':
            Q = torch.einsum("nm,hm->nhm", x1, self.Ws)  # [n, h, m]
            K = torch.einsum("lm,hm->lhm", x2, self.Ws)  # [l, h, m]
            # Q = torch.einsum("nm,hm->nhm", x1, self.Ws) + self.Ws_bias  # [n, h, m]
            # K = torch.einsum("lm,hm->lhm", x2, self.Ws) + self.Ws_bias  # [l, h, m]

        elif self.func == 'm-cos':
            Q = self.Wm(x1).reshape(-1, self.heads, self.channels)  # [n, h, m]
            K = self.Wm(x2).reshape(-1, self.heads, self.channels)  # [l, h, m]

        elif self.func == 'qk-cos':
            Q = self.Wq(x1).reshape(-1, self.heads, self.channels)  # [n, h, m]
            K = self.Wk(x2).reshape(-1, self.heads, self.channels)  # [l, h, m]

        eps = 1e-10 if self.func == 'w-cos' else 0.0
        dim = 2 if self.norm == 'l2' else (0, 2)
        Q = Q / ((torch.norm(Q, p=2, dim=dim, keepdim=True)) + eps)  # [n, h, m]
        K = K / ((torch.norm(K, p=2, dim=dim, keepdim=True)) + eps)  # [l, h, m]

        if get_attention:
            attention = torch.einsum('nhm,lhm->nhl', Q, K)
            attention = attention.mean(dim=1)
            return attention

        V = x2.unsqueeze(1).expand(-1, self.heads, -1)  # [l, h, d]
        O = transformer_layer(Q, K, V).mean(dim=1)  # [n, d]
        return O


# func: ('cos', 'w-cos', 'm-cos', 'qk-cos')
# norm: ('l2', 'fro')
class ExFormer(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=8, 
                 use_ln=True, dropout=0.5, activ=F.relu, 
                 heads=1, transform=False, func='qk-cos', norm='l2', alpha=0.5, beta=1.0):
        super(ExFormer, self).__init__()

        self.fc1 = nn.Linear(in_channels, hidden_channels)
        self.fc2 = nn.ModuleList()
        if use_ln:
            self.ln1 = nn.LayerNorm(hidden_channels)
            self.ln2 = nn.ModuleList()

        self.tfs = nn.ModuleList()
        for _ in range(num_layers):
            self.tfs.append(TransformerLayer(hidden_channels, heads=heads, func=func, norm=norm))
            if transform:
                self.fc2.append(nn.Linear(hidden_channels, hidden_channels))
            if use_ln:
                self.ln2.append(nn.LayerNorm(hidden_channels))

        self.fc2.append(nn.Linear(hidden_channels, out_channels))

        self.num_layers = num_layers
        self.use_ln = use_ln
        self.dropout = dropout
        self.activ = activ
        self.transform = transform
        self.alpha = alpha
        self.beta = beta

    def reset_parameters(self):
        self.fc1.reset_parameters()
        for fc in self.fc2:
            fc.reset_parameters()
        for tf in self.tfs:
            tf.reset_parameters()
        if self.use_ln:
            self.ln1.reset_parameters()
            for ln in self.ln2:
                ln.reset_parameters()

    def forward(self, data):
        x = data.x
        adj = data.train_adj if self.training else data.adj

        # x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.fc1(x)
        if self.use_ln:
            x = self.ln1(x)
        x = self.activ(x)
        x0 = x.clone()

        for i in range(self.num_layers):
            x = F.dropout(x, p=self.dropout, training=self.training)
            if self.transform:
                x = self.activ(self.fc2[i](
                        self.beta * 0.5 * self.alpha * self.tfs[i](x, x) + \
                        self.beta * 0.5 * (1 - self.alpha) * matmul(adj, x)
                    )) + \
                    self.beta * 0.5 * x + \
                    (1 - self.beta) * x0
            else:
                x = self.beta * 0.5 * self.alpha * self.tfs[i](x, x) + \
                    self.beta * 0.5 * (1 - self.alpha) * matmul(adj, x) + \
                    self.beta * 0.5 * x + \
                    (1 - self.beta) * x0

            if self.use_ln:
                x = self.ln2[i](x)

        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.fc2[-1](x)
        return x

    '''
    def forward(self, data):
        x = data.x
        adj = data.train_adj if self.training else data.adj

        x = self.fc0[0](x)
        if self.use_ln:
            x = self.ln0[0](x)
        x = self.activation(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        P = self.tfs[0](x, x, get_attention=True)
        A = adj.to_dense().to(P.device)
        P_A = self.alpha * P + (1 - self.alpha) * A

        tensors = {'P': P, 'A': A, 'P_A': P_A}
        for name, tensor in tensors.items():
            _, s, _ = torch.svd(tensor)
            rank = (s > 1e-8).sum().item()
            torch.save(tensor, name + '_rank=' + str(rank) + '.pt')
            print(name + ' Rank: ', rank)
    '''
