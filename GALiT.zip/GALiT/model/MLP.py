import torch.nn as nn
import torch.nn.functional as F


class MLP(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=2, 
                 use_ln=False, dropout=0.5, activ=F.relu):
        super(MLP, self).__init__()

        self.use_ln = use_ln
        self.dropout = dropout
        self.activ = activ

        self.conv1 = nn.Linear(in_channels, hidden_channels)
        self.ln1 = nn.LayerNorm(hidden_channels)

        self.conv2 = nn.ModuleList()
        self.ln2 = nn.ModuleList()
        for _ in range(num_layers-2):
            self.conv2.append(nn.Linear(hidden_channels, hidden_channels))
            self.ln2.append(nn.LayerNorm(hidden_channels))

        self.conv2.append(nn.Linear(hidden_channels, out_channels))


    def reset_parameters(self):
        self.conv1.reset_parameters()
        self.ln1.reset_parameters()
        for conv in self.conv2:
            conv.reset_parameters()
        for ln in self.ln2:
            ln.reset_parameters()


    def forward(self, x):
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv1(x)
        if self.use_ln:
            x = self.ln1(x)
        x = self.activ(x)

        for conv, ln in zip(self.conv2[:-1], self.ln2):
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = conv(x)
            if self.use_ln:
                x = ln(x)
            x = self.activ(x)

        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv2[-1](x)
        return x
