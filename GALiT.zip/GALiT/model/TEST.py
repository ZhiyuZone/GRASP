import torch.nn as nn
import torch.nn.functional as F
# from torch_geometric.nn import APPNP as APPNPConv


class TEST(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=10, 
                 dropout=0.5, alpha=0.1):
        super(TEST, self).__init__()

        self.dropout = dropout
        # self.prop = APPNPConv(K=num_layers, alpha=alpha)
        self.lin1 = nn.Linear(in_channels, hidden_channels)
        self.lin2 = nn.Linear(hidden_channels, out_channels)
        # self.lin2 = nn.Linear(hidden_channels, out_channels, bias=False)


    def reset_parameters(self):
        self.lin1.reset_parameters()
        self.lin2.reset_parameters()


    def forward(self, x):
        '''
        if not data.is_prop:
            data.x_prop_train = self.prop(data.x, data.train_edge_index)
            data.x_prop_test = self.prop(data.x, data.edge_index)
            data.is_prop = True
        x = data.x_prop_train if self.training else data.x_prop_test

        if not data.is_prop:
            data.x = self.prop(data.x, data.edge_index)
            data.is_prop = True
        x = data.x
        '''
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin1(x)
        x = F.relu(x)

        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin2(x)
        return x
