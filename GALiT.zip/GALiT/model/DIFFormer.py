import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.utils import degree
from torch_sparse import SparseTensor, matmul


def transformer_conv(qs, ks, vs, kernel, output_att=False):

    '''
    qs: query tensor [N, H, M]
    ks: key tensor [L, H, M]
    vs: value tensor [L, H, D]
    return output [N, H, D]
    '''

    if kernel == 'simple':

        # qs = F.relu(qs)
        # ks = F.relu(ks)

        '''

        a = 1.

        qs_t = torch.exp(a * torch.abs(qs)) * qs  # 1
        # qs_t = torch.exp(a * qs) * qs  # 1
        # qs_t = (torch.abs(qs) + 1).pow(a) * qs  # 2
        # qs_t = (qs + 1).pow(a) * qs  # 2
        # qs_t = (torch.abs(qs) + 1).pow(a)  # 3
        # qs_t = qs.pow(a)  # 3

        ks_t = torch.exp(a * torch.abs(ks)) * ks  # 1
        # ks_t = torch.exp(a * ks) * ks  # 1
        # ks_t = (torch.abs(ks) + 1).pow(a) * ks  # 2
        # ks_t = (ks + 1).pow(a) * ks  # 2
        # ks_t = (torch.abs(ks) + 1).pow(a)  # 3
        # ks_t = ks.pow(a)  # 3

        qs_t_norm = torch.norm(qs_t, p=2, dim=2, keepdim=True) + 1e-8
        qs_norm = torch.norm(qs, p=2, dim=2, keepdim=True)
        qs = qs_norm * qs_t / qs_t_norm

        ks_t_norm = torch.norm(ks_t, p=2, dim=2, keepdim=True) + 1e-8
        ks_norm = torch.norm(ks, p=2, dim=2, keepdim=True)
        ks = ks_norm * ks_t / ks_t_norm

        '''

        N = vs.shape[0]

        # numerator
        kvs = torch.einsum("lhm,lhd->hmd", ks, vs)
        att_sum = torch.einsum("nhm,hmd->nhd", qs, kvs)  # [N, H, D]
        ones = torch.ones(N).to(vs.device)
        vs_sum = torch.einsum("l,lhd->hd", ones, vs)  # [H, D]
        att_sum += vs_sum.unsqueeze(0).repeat(N, 1, 1)  # [N, H, D]

        # denominator
        ones = torch.ones(N).to(ks.device)
        ks_sum = torch.einsum("lhm,l->hm", ks, ones)
        att_norm = torch.einsum("nhm,hm->nh", qs, ks_sum)  # [N, H]

        # attentive aggregated results
        att_norm = att_norm.unsqueeze(-1)  # [N, H, 1]
        att_norm += N
        transformer_output = att_sum / att_norm  # [N, H, D]

        # compute attention for visualization if needed
        if output_att:
            att = (torch.einsum("nhm,lhm->nlh", qs, ks) + 1) / att_norm  # [N, L, H]

    elif kernel == 'sigmoid':
        N = vs.shape[0]

        # numerator
        att_sum = torch.sigmoid(torch.einsum("nhm,lhm->nlh", qs, ks))  # [N, L, H]

        # denominator
        ones = torch.ones(N).to(ks.device)
        att_norm = torch.einsum("nlh,l->nh", att_sum, ones)
        att_norm = att_norm.unsqueeze(1).repeat(1, N, 1)  # [N, L, H]

        # compute attention and attentive aggregated results
        att = att_sum / att_norm
        transformer_output = torch.einsum("nlh,lhd->nhd", att, vs)  # [N, H, D]

    if output_att:
        return transformer_output, att_norm, att
    else:
        return transformer_output, att_norm


def gcn_conv(vs, edge_index, edge_weight):
    N, H = vs.shape[0], vs.shape[1]
    row, col = edge_index
    d = degree(col, N).float()
    d_norm_in = (1. / d[col]).sqrt()
    d_norm_out = (1. / d[row]).sqrt()
    gcn_conv_output = []
    if edge_weight is None:
        val = torch.ones_like(row) * d_norm_in * d_norm_out
    else:
        val = edge_weight * d_norm_in * d_norm_out
    val = torch.nan_to_num(val, nan=0.0, posinf=0.0, neginf=0.0)
    adj = SparseTensor(row=col, col=row, value=val, sparse_sizes=(N, N))
    for h in range(H):
        gcn_conv_output.append(matmul(adj, vs[:, h]))  # [N, D]
    gcn_conv_output = torch.stack(gcn_conv_output, dim=1)  # [N, H, D]
    return gcn_conv_output, adj


def gat_conv(qs, ks, vs, adj, att_norm):
    N, H = vs.shape[0], vs.shape[1]
    row, col, val = adj.coo()
    gat_conv_output = []
    for h in range(H):
        products = (qs[row, h] * ks[col, h]).sum(dim=1, keepdim=True)
        products = (products + 1) / att_norm[row, h]
        val_mul = products.squeeze() * val
        adj_mul = SparseTensor(row=row, col=col, value=val_mul, sparse_sizes=(N, N))
        gat_conv_output.append(matmul(adj_mul, vs[:, h]))  # [N, D]
    gat_conv_output = torch.stack(gat_conv_output, dim=1)  # [N, H, D]
    return gat_conv_output


class DIFFormerConv(nn.Module):
    def __init__(self, in_channels, out_channels, num_heads, kernel='simple', use_graph=True, use_weight=False):
        super(DIFFormerConv, self).__init__()

        self.Wq = nn.Linear(in_channels, out_channels * num_heads)
        self.Wk = nn.Linear(in_channels, out_channels * num_heads)
        if use_weight:
            self.Wv = nn.Linear(in_channels, out_channels * num_heads)

        self.out_channels = out_channels
        self.num_heads = num_heads
        self.kernel = kernel
        self.use_graph = use_graph
        self.use_weight = use_weight

    def reset_parameters(self):
        self.Wq.reset_parameters()
        self.Wk.reset_parameters()
        if self.use_weight:
            self.Wv.reset_parameters()

    def forward(self, x1, x2, edge_index=None, edge_weight=None, output_att=False):
        # feature transformation
        qs = self.Wq(x1).reshape(-1, self.num_heads, self.out_channels)
        ks = self.Wk(x2).reshape(-1, self.num_heads, self.out_channels)
        if self.use_weight:
            vs = self.Wv(x2).reshape(-1, self.num_heads, self.out_channels)
        else:
            vs = x2.reshape(-1, 1, self.out_channels)  # ???

        qs = qs / torch.norm(qs, p=2, dim=(0, 2), keepdim=True)
        ks = ks / torch.norm(ks, p=2, dim=(0, 2), keepdim=True)

        # compute full attentive aggregation
        if output_att:
            transformer_output, att_norm, att = transformer_conv(qs, ks, vs, self.kernel, output_att)  # [N, H, D]
        else:
            transformer_output, att_norm = transformer_conv(qs, ks, vs, self.kernel) # [N, H, D]

        # use input graph for gcn conv
        if self.use_graph:
            gcn_conv_output, adj = gcn_conv(vs, edge_index, edge_weight)
            gat_conv_output = gat_conv(qs, ks, vs, adj, att_norm)
            all_output = 1.0 * transformer_output + 1.0 * gcn_conv_output + 0.0 * gat_conv_output
        else:
            all_output = transformer_output

        all_output = all_output.mean(dim=1)

        if output_att:
            return all_output, att
        else:
            return all_output


class DIFFormer(nn.Module):

    '''
    x: input node features [N, D]
    edge_index: 2-dim indices of edges [2, E]
    return y_hat predicted logits [N, C]
    '''

    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=8, num_heads=1, kernel='simple',
                 alpha=0.5, dropout=0.2, use_ln=True, use_residual=True, use_weight=False, use_graph=True):
        super(DIFFormer, self).__init__()

        self.convs = nn.ModuleList()
        self.fcs = nn.ModuleList()
        self.lns = nn.ModuleList()

        self.fcs.append(nn.Linear(in_channels, hidden_channels))
        self.lns.append(nn.LayerNorm(hidden_channels))

        for _ in range(num_layers):
            self.convs.append(DIFFormerConv(hidden_channels, hidden_channels, num_heads, kernel, use_graph, use_weight))
            self.lns.append(nn.LayerNorm(hidden_channels))

        self.fcs.append(nn.Linear(hidden_channels, out_channels))

        self.dropout = dropout
        self.activation = F.relu
        self.use_ln = use_ln
        self.residual = use_residual
        self.alpha = alpha

    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()
        for fc in self.fcs:
            fc.reset_parameters()
        for ln in self.lns:
            ln.reset_parameters()

    def forward(self, data, edge_weight=None):
        x = data.x
        edge_index = data.train_edge_index if self.training else data.edge_index
        layers = []

        # input MLP layer
        x = self.fcs[0](x)
        if self.use_ln:
            x = self.lns[0](x)
        x = self.activation(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        # store as residual link
        layers.append(x)

        for i, conv in enumerate(self.convs):
            # graph convolution with DIFFormer layer
            x = conv(x, x, edge_index, edge_weight)
            if self.residual:
                x = self.alpha * x + (1 - self.alpha) * layers[i]
            if self.use_ln:
                x = self.lns[i+1](x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            layers.append(x)

        # output MLP layer
        x_out = self.fcs[-1](x)
        return x_out

    def get_attentions(self, data):
        x = data.x
        layers, attentions = [], []

        x = self.fcs[0](x)
        if self.use_ln:
            x = self.lns[0](x)
        x = self.activation(x)

        layers.append(x)

        for i, conv in enumerate(self.convs):
            x, att = conv(x, x, output_att=True)
            attentions.append(att)
            if self.residual:
                x = self.alpha * x + (1 - self.alpha) * layers[i]
            if self.use_ln:
                x = self.lns[i+1](x)
            layers.append(x)

        return torch.stack(attentions, dim=0)  # [layer num, N, N]
