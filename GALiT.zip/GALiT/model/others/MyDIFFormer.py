import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_sparse import SparseTensor, matmul
from torch_geometric.utils import degree


def gcn_conv(x, edge_index):
    N = x.shape[0]
    row, col = edge_index
    d = degree(col, N).float()
    d_norm_in = (1. / d[col]).sqrt()
    d_norm_out = (1. / d[row]).sqrt()
    value = torch.ones_like(row) * d_norm_in * d_norm_out
    value = torch.nan_to_num(value, nan=0.0, posinf=0.0, neginf=0.0)
    adj = SparseTensor(row=col, col=row, value=value, sparse_sizes=(N, N))
    gcn_conv_output = matmul(adj, x)
    return gcn_conv_output


class DIFFormerConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DIFFormerConv, self).__init__()
        self.Wq = nn.Linear(in_channels, out_channels)
        self.Wk = nn.Linear(in_channels, out_channels)
        self.Wv = nn.Linear(in_channels, out_channels)


    def reset_parameters(self):
        self.Wq.reset_parameters()
        self.Wk.reset_parameters()
        self.Wv.reset_parameters()


    def forward(self, x, edge_index):
        Q = self.Wq(x)
        Q = Q / torch.norm(Q, p=2)
        
        Q = F.relu(Q)
        Q_norm = torch.norm(Q, p=2, dim=1).unsqueeze(1)
        Q_power = Q.pow(1.5)
        Q_norm_power = torch.norm(Q_power, p=2, dim=1).unsqueeze(1)
        Q = (Q_power * Q_norm) / Q_norm_power
        
        # Q = Q / torch.norm(Q, p=2)
        # Q = Q / torch.norm(Q, p=2, dim=1).unsqueeze(1)
        K = self.Wk(x)
        K = K / torch.norm(K, p=2)
        
        K = F.relu(K)
        K_norm = torch.norm(K, p=2, dim=1).unsqueeze(1)
        K_power = K.pow(1.5)
        K_norm_power = torch.norm(K_power, p=2, dim=1).unsqueeze(1)
        K = (K_power * K_norm) / K_norm_power
        
        # K = K / torch.norm(K, p=2)
        # K = K / torch.norm(K, p=2, dim=1).unsqueeze(1)
        V = x
        # V = self.Wv(x)

        N = x.size(0)
        D = Q @ torch.sum(K, dim=0).unsqueeze(-1) + N
        # Z1 = Q @ (K.T @ V) + N * V
        Z1 = Q @ (K.T @ V) + torch.sum(V, dim=0)
        Z1 = Z1 / D
        Z2 = gcn_conv(x, edge_index)
        Z = Z1 + Z2

        return Z


class DIFFormer(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=8, alpha=0.5, dropout=0.5, use_ln=True, activation=F.relu):
        super(DIFFormer, self).__init__()

        self.alpha = alpha
        self.dropout = dropout
        self.use_ln = use_ln
        self.activation = activation

        self.fcs = nn.ModuleList()
        self.convs = nn.ModuleList()
        self.lns = nn.ModuleList()

        self.fcs.append(nn.Linear(in_channels, hidden_channels))
        self.lns.append(nn.LayerNorm(hidden_channels))

        for _ in range(num_layers):
            self.convs.append(DIFFormerConv(hidden_channels, hidden_channels))
            self.lns.append(nn.LayerNorm(hidden_channels))
        
        self.fcs.append(nn.Linear(hidden_channels, out_channels))


    def reset_parameters(self):
        for fc in self.fcs:
            fc.reset_parameters()
        for conv in self.convs:
            conv.reset_parameters()
        for ln in self.lns:
            ln.reset_parameters()


    def forward(self, x, edge_index):
        layer = []

        x = self.fcs[0](x)
        if self.use_ln:
            x = self.lns[0](x)
        x = self.activation(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        layer.append(x)

        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)
            x = self.alpha * x + (1 - self.alpha) * layer[i]
            if self.use_ln:
                x = self.lns[i+1](x)
            # x = self.activation(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            layer.append(x)
        
        x = self.fcs[-1](x)
        
        return x
