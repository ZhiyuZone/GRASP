import torch
import torch.nn as nn
import torch.nn.functional as F


def transformer_layer(Q, K, V):
    # Q: [n, m]    K: [l, m]    V: [l, d]    O: [n, d]
    att_value = torch.matmul(Q, torch.matmul(K.T, V)) + V.sum(dim=0)  # [n, d]
    att_norm = torch.matmul(Q, K.sum(dim=0).unsqueeze(-1)) + K.size(0)  # [n, 1]
    return att_value / att_norm  # [n, d]


class TransformerLayer(nn.Module):
    def __init__(self, in_channels, hidden_channels, func='qk-cos', norm='l2'):
        super(TransformerLayer, self).__init__()

        if func == 'cos':
            pass
        elif func == 'w-cos':
            self.Ws = nn.Parameter(torch.ones(1, in_channels))
        elif func == 'm-cos':
            self.Wm = nn.Linear(in_channels, hidden_channels)
        elif func == 'qk-cos':
            self.Wq = nn.Linear(in_channels, hidden_channels)
            self.Wk = nn.Linear(in_channels, hidden_channels)
        else:
            raise ValueError(f'Invalid func: {func}')

        if norm not in ('l2', 'fro'):
            raise ValueError(f'Invalid norm: {norm}')

        self.func = func
        self.norm = norm

    def reset_parameters(self):
        if self.func == 'w-cos':
            nn.init.ones_(self.Ws)
        elif self.func == 'm-cos':
            self.Wm.reset_parameters()
        elif self.func == 'qk-cos':
            self.Wq.reset_parameters()
            self.Wk.reset_parameters()

    def forward(self, x):
        # x1: [n, m]    x2: [l, m]    x3: [l, d]    O: [n, d]
        eps = 1e-10
        dim = 1 if self.norm == 'l2' else (0, 1)

        if self.func == 'cos':
            Q = K = x / ((torch.norm(x, p=2, dim=dim, keepdim=True)) + eps)

        elif self.func == 'w-cos':
            Q = self.Ws * x
            Q = K = Q / ((torch.norm(Q, p=2, dim=dim, keepdim=True)) + eps)

        elif self.func == 'm-cos':
            Q = self.Wm(x)
            Q = K = Q / ((torch.norm(Q, p=2, dim=dim, keepdim=True)) + eps)

        elif self.func == 'qk-cos':
            Q, K = self.Wq(x), self.Wk(x)
            Q, K = Q / ((torch.norm(Q, p=2, dim=dim, keepdim=True)) + eps), \
                   K / ((torch.norm(K, p=2, dim=dim, keepdim=True)) + eps)

        return transformer_layer(Q, K, x)  # [n, d]


# func: ('cos', 'w-cos', 'm-cos', 'qk-cos')
# norm: ('l2', 'fro')
class GALiT(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers=8, 
                 use_ln=True, dropout=0.5, activ=F.relu, 
                 transform=False, func='m-cos', norm='l2', alpha=0.5, beta=0.5):
        super(GALiT, self).__init__()

        self.fc1 = nn.Linear(in_channels, hidden_channels)
        self.fc2 = nn.Linear(hidden_channels, out_channels)
        self.fcs = nn.ModuleList()
        self.ln1 = nn.LayerNorm(hidden_channels)
        self.ln2 = nn.ModuleList()
        self.tfs = nn.ModuleList()
        for _ in range(num_layers):
            self.tfs.append(TransformerLayer(hidden_channels, hidden_channels, func=func, norm=norm))
            if transform:
                self.fcs.append(nn.Linear(hidden_channels, hidden_channels))
            self.ln2.append(nn.LayerNorm(hidden_channels))

        self.num_layers = num_layers
        self.use_ln = use_ln
        self.dropout = dropout
        self.activ = activ
        self.transform = transform
        self.alpha = alpha
        self.beta = beta

    def reset_parameters(self):
        self.fc1.reset_parameters()
        self.fc2.reset_parameters()
        if self.transform:
            for fc in self.fcs:
                fc.reset_parameters()
        self.ln1.reset_parameters()
        for ln in self.ln2:
            ln.reset_parameters()
        for tf in self.tfs:
            tf.reset_parameters()

    def forward(self, x, x_):
        x, x_ = self.fc1(x), self.fc1(x_)
        if self.use_ln:
            x, x_ = self.ln1(x), self.ln1(x_)
        x, x_ = self.activ(x), self.activ(x_)

        for i in range(self.num_layers):
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = (1 - self.alpha) * x + self.alpha * self.tfs[i](x)
            if self.transform:
                x = self.fcs[i](x)
            x = (1 - self.beta) * x + self.beta * x_
            if self.use_ln:
                x = self.ln2[i](x)
            if self.transform:
                x = self.activ(x)

        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.fc2(x)
        return x
