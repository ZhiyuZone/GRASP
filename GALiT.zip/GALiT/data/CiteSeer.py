from ._utilities import load_Planetoid, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_CiteSeer(args, analysis=True):
    if args.split in ('public', 'random', 'full', 'geom-gcn'):
        data = load_Planetoid(args)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
