from .Cora import load_Cora
from .CiteSeer import load_CiteSeer
from .PubMed import load_PubMed
from .Cora_full import load_Cora_full

from .Squirrel import load_Squirrel
from .Chameleon import load_Chameleon
from .Actor import load_Actor

from .Cornell import load_Cornell
from .Wisconsin import load_Wisconsin
from .Texas import load_Texas

from .ogbn_arxiv import load_ogbn_arxiv
from .pokec import load_pokec
from .ogbn_products import load_ogbn_products
from .ogbn_papers import load_ogbn_papers

from .ogbn_proteins import load_ogbn_proteins
from .ogbn_mag import load_ogbn_mag
from .snap_patents import load_snap_patents
