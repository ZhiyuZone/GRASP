import os
from torch_geometric.datasets import Actor
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_Actor(args, analysis=True):
    dataset = Actor(root=os.path.join(args.root, 'Actor'))
    data = dataset._data
    data.num_classes = dataset.num_classes
    data.edge_index = data.edge_index
    data.train_masks = data.train_mask.t()
    data.val_masks = data.val_mask.t()
    data.test_masks = data.test_mask.t()
    data.train_mask = data.train_masks[0]
    data.val_mask = data.val_masks[0]
    data.test_mask = data.test_masks[0]

    if args.split == 'public':
        pass
    elif args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
