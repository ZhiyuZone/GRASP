import torch
import numpy as np
import scipy.sparse as sp
from torch_geometric.data import Data
from ._utilities import load_Planetoid, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis, encode_onehot


def load_Cora(args, analysis=True):
    if args.split in ('public', 'random', 'full', 'geom-gcn'):
        data = load_Planetoid(args)
    elif args.split == 'public-gat':
        data = load_Cora_GAT(args)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data


def load_Cora_GAT(args):
    dataset_path = args.root + '/Cora_GAT'

    idx_features_labels = np.genfromtxt(f'{dataset_path}/cora.content', dtype=np.dtype(str))
    edges_unordered = np.genfromtxt(f'{dataset_path}/cora.cites', dtype=np.int32)

    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)
    labels = encode_onehot(idx_features_labels[:, -1])

    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)
    idx_map = {j: i for i, j in enumerate(idx)}
    edges = np.array([idx_map[i] for i in edges_unordered.flatten()], dtype=np.int32).reshape(edges_unordered.shape)
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])), shape=(labels.shape[0], labels.shape[0]), dtype=np.float32)
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.where(labels)[1])
    adj = adj.tocoo()
    edge_index = torch.LongTensor(np.vstack((adj.row, adj.col)))

    train_mask = torch.zeros(labels.shape[0], dtype=torch.bool)
    val_mask = torch.zeros(labels.shape[0], dtype=torch.bool)
    test_mask = torch.zeros(labels.shape[0], dtype=torch.bool)
    train_mask[range(140)] = True
    val_mask[range(200, 500)] = True
    test_mask[range(500, 1500)] = True

    data = Data(x=features, edge_index=edge_index, y=labels)
    data.train_mask = train_mask
    data.val_mask = val_mask
    data.test_mask = test_mask
    data.edge_attr = None
    data.num_classes = labels.max().item() + 1
    
    return data
