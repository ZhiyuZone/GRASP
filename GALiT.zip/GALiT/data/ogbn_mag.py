import torch
from ogb.nodeproppred import PygNodePropPredDataset
from torch_geometric.transforms import ToSparseTensor
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_ogbn_mag(args, analysis=True):
    transform = ToSparseTensor()
    dataset = PygNodePropPredDataset(name='ogbn-mag',
                                     root=args.root,
                                     transform=transform)
    data = dataset._data
    data.num_classes = dataset.num_classes
    data.y = data.y.squeeze(1)

    if args.split == 'public':
        split_idx = dataset.get_idx_split()
        train_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        val_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        test_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        train_mask[split_idx['train']] = True
        val_mask[split_idx['valid']] = True
        test_mask[split_idx['test']] = True
        data.train_mask = train_mask
        data.val_mask = val_mask
        data.test_mask = test_mask
    elif args.split in ['random', 'full']:
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')
    
    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
