import torch
import numpy as np
from torch_geometric.datasets import Planetoid
from torch_geometric.transforms import RandomNodeSplit, NormalizeFeatures
from torch_geometric.utils import to_undirected, remove_self_loops, add_self_loops, degree
from torch_geometric.nn import knn_graph
from torch_sparse import SparseTensor


def load_Planetoid(args):
    dataset = Planetoid(root=args.root, name=args.dataset, split=args.split)
    data = dataset[0]
    data.num_classes = dataset.num_classes
    if args.split in ('random', 'full'):
        random_data_split(args, data)
    elif args.split == 'geom-gcn':
        data.train_masks = data.train_mask.bool().T
        data.val_masks = data.val_mask.bool().T
        data.test_masks = data.test_mask.bool().T
        data.train_mask = data.train_masks[0]
        data.val_mask = data.val_masks[0]
        data.test_mask = data.test_masks[0]
    return data


def random_data_split(args, data):
    if args.split == 'random':
        transform = RandomNodeSplit(split='random',
                                    num_train_per_class=args.num_train_per_class, 
                                    num_val=args.num_val, 
                                    num_test=args.num_test)
    elif args.split == 'full':
        transform = RandomNodeSplit(split='train_rest', 
                                    num_val=args.ratio_val, 
                                    num_test=args.ratio_test)
    transform(data)


def edge_preprocess(data):
    # mask = data.y[data.edge_index[0]] == data.y[data.edge_index[1]]
    # data.edge_index = data.edge_index[:, mask]
    data.edge_index = to_undirected(data.edge_index)
    data.edge_index, _ = remove_self_loops(data.edge_index)
    data.edge_index, _ = add_self_loops(data.edge_index, num_nodes=data.num_nodes)
    data.adj = adj_norm(data)


def adj_norm(data):
    edge_index = data.edge_index
    num_nodes = data.num_nodes

    row, col = edge_index
    d = degree(col, num_nodes).float().clamp(min=1)
    d_inv_sqrt = d.pow(-0.5)

    norm = d_inv_sqrt[row] * d_inv_sqrt[col]
    norm = torch.nan_to_num(norm, nan=0.0, posinf=0.0, neginf=0.0)
    adj = SparseTensor(row=row, col=col, value=norm, sparse_sizes=(num_nodes, num_nodes))
    return adj


def encode_onehot(labels):
    classes, indices = np.unique(labels, return_inverse=True)
    labels_onehot = np.eye(len(classes))[indices].astype(np.int32)
    return labels_onehot


def normalize_features(data):
    transform = NormalizeFeatures()
    transform(data)


def reconstruct(args, data):
    data.edge_index = knn_graph(data.x, args.k, loop=args.loop, cosine=args.cosine)


def setting_preprocess(args, data):
    if args.setting == 'transductive':
        data.train_edge_index = data.edge_index
        # data.train_adj = data.adj

        # data.val_edge_index = data.edge_index
        # data.val_adj = data.adj

    else:
        train_edge_index_mask = data.train_mask[data.edge_index[0]] & data.train_mask[data.edge_index[1]]
        # data.train_edge_index = data.edge_index[:, train_edge_index_mask]
        # data.train_adj = adj_norm(data.train_edge_index, data.num_nodes)

        # train_val_mask = data.train_mask | data.val_mask
        # val_edge_index_mask = train_val_mask[data.edge_index[0]] & train_val_mask[data.edge_index[1]]
        # data.val_edge_index = data.edge_index[:, val_edge_index_mask]
        # data.val_adj = adj_norm(data.val_edge_index, data.num_nodes)


def graph_analysis(args, data):
    print('-------------------------Data-------------------------')

    print(f'[Name] {args.dataset}')

    print(f'[Class] {data.num_classes}')

    num_nodes = data.num_nodes
    print(f'[Node] {num_nodes}')

    num_edges = data.edge_index.shape[1]
    print(f'[Edge] {num_edges // 2}')

    print(f'[Dimension] {data.num_features}')

    def node_homophily(edge_index, labels):
        edge_counts = torch.bincount(edge_index[0], minlength=num_nodes).float()
        same_label_counts = torch.bincount(edge_index[0, labels[edge_index[0]] == labels[edge_index[1]]], minlength=num_nodes).float()
        homophily = torch.where(edge_counts > 0, same_label_counts / edge_counts, torch.zeros(num_nodes))
        return homophily.mean().item()

    def edge_homophily(edge_index, labels):
        if num_edges == 0:
            return 0
        edge_labels_1 = labels[edge_index[0, :]]
        edge_labels_2 = labels[edge_index[1, :]]
        return (edge_labels_1 == edge_labels_2).sum().item() / num_edges

    h_node = node_homophily(data.edge_index, data.y)
    h_edge = edge_homophily(data.edge_index, data.y)
    print(f'[Homophily] Node: {h_node:.4f} | Edge: {h_edge:.4f}')

    num_train = data.train_mask.sum().item()
    num_val = data.val_mask.sum().item()
    num_test = data.test_mask.sum().item()
    ratio_train = num_train / num_nodes * 100
    ratio_val = num_val / num_nodes * 100
    ratio_test = num_test / num_nodes * 100

    print(f'[Split] Train: {num_train} ({ratio_train:.2f}%) | Val: {num_val} ({ratio_val:.2f}%) | Test: {num_test} ({ratio_test:.2f}%)')
    print('------------------------------------------------------')
