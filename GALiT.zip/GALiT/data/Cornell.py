from torch_geometric.datasets import WebKB
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_Cornell(args, analysis=True):
    name = 'Cornell'
    dataset = WebKB(root=args.root+'/'+name, name=name)
    data = dataset[0]
    data.num_classes = dataset.num_classes

    if args.split == 'public':
        data.train_masks = data.train_mask.bool().T
        data.val_masks = data.val_mask.bool().T
        data.test_masks = data.test_mask.bool().T
        data.train_mask = data.train_masks[0]
        data.val_mask = data.val_masks[0]
        data.test_mask = data.test_masks[0]
    elif args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
