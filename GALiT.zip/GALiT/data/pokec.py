import os
import torch
import gdown
import scipy.io
from torch_geometric.data import Data
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_pokec(args, analysis=True):
    dataset_drive_url = '1dNs5E7BrWJbgcHeQ_zuy5Ozp2tRCWG0y'
    filename = f'{args.root}/pokec/pokec.mat'
    if not os.path.exists(filename):
        gdown.download(id=dataset_drive_url, 
                       output=filename, 
                       quiet=False)
    fulldata = scipy.io.loadmat(filename)

    x = torch.tensor(fulldata['node_feat'], dtype=torch.float)
    edge_index = torch.tensor(fulldata['edge_index'], dtype=torch.long)
    y = torch.tensor(fulldata['label'].flatten(), dtype=torch.long)
    y[y == -1] = 1
    data = Data(x=x, edge_index=edge_index, y=y)
    data.num_classes = torch.unique(data.y).shape[0]

    if args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
