import os
import torch
import numpy as np
from torch_geometric.data import Data
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_Squirrel(args, analysis=True):
    data = np.load(os.path.join(args.root, 'Squirrel', 'squirrel.npz'))
    features = torch.tensor(data['node_features'])
    # edges = torch.tensor([[0], [0]])
    edges = torch.tensor(data['edges']).T
    labels = torch.tensor(data['node_labels'])
    train_masks = torch.tensor(data['train_masks'])
    val_masks = torch.tensor(data['val_masks'])
    test_masks = torch.tensor(data['test_masks'])

    data = Data(x=features, edge_index=edges, y=labels)
    data.train_mask = train_masks[0]
    data.val_mask = val_masks[0]
    data.test_mask = test_masks[0]
    data.num_classes = len(labels.unique())

    if args.split == 'public':
        data.train_masks = train_masks
        data.val_masks = val_masks
        data.test_masks = test_masks
    elif args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
