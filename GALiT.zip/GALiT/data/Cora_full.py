from torch_geometric.datasets import CoraFull
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_Cora_full(args, analysis=True):
    dataset = CoraFull(root=args.root+'/Cora_full')
    data = dataset[0]
    data.num_classes = dataset.num_classes

    if args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    return data
