import torch
from ogb.nodeproppred import PygNodePropPredDataset
from torch_geometric.transforms import ToSparseTensor
from ._utilities import random_data_split, normalize_features, reconstruct, edge_preprocess, setting_preprocess, graph_analysis


def load_ogbn_papers(args, analysis=True):
    transform = ToSparseTensor()
    dataset = PygNodePropPredDataset(root=args.root, 
                                     name='ogbn-papers100M', 
                                     transform=transform)
    data = dataset._data
    data.num_classes = dataset.num_classes
    data.y = data.y.squeeze().long()

    if args.split == 'public':
        split_idx = dataset.get_idx_split()
        data.train_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        data.val_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        data.test_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        data.train_mask[split_idx['train']] = True
        data.val_mask[split_idx['valid']] = True
        data.test_mask[split_idx['test']] = True
    elif args.split in ('random', 'full'):
        random_data_split(args, data)
    else:
        raise ValueError(f'Invalid split: {args.split}')

    if args.normalize_features:
        normalize_features(data)

    if args.reconstruct:
        reconstruct(args, data)

    edge_preprocess(data)

    setting_preprocess(args, data)

    if analysis:
        graph_analysis(args, data)

    '''
    compute_and_save_appnp_features(data, 
                                    device=args.device,
                                    save_path='./data/raw/ogbn_papers100M/saved/appnp_features.h5',
                                    batch_size=1024,
                                    appnp_k=5,
                                    appnp_alpha=0.05)

    load_appnp_features(data,
                        load_path='./data/raw/ogbn_papers100M/saved/appnp_features.h5')
    '''

    return data


'''
from torch_geometric.nn import APPNP
from torch_geometric.loader import NeighborSampler
import h5py
from tqdm import tqdm

def compute_and_save_appnp_features_batch(data, device, save_path, batch_size=1024, appnp_k=2, appnp_alpha=0.05):
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    appnp = APPNP(K=appnp_k, alpha=appnp_alpha).to(device)
    loader = NeighborSampler(data.edge_index, node_idx=None, sizes=[-1] * appnp_k, batch_size=batch_size, shuffle=False, num_workers=4)

    processed_nodes = set()  # Track processed nodes to avoid duplicates
    all_features = np.zeros((data.num_nodes, data.num_features), dtype=np.float)  # Preallocate feature matrix

    for batch_size, n_id, adjs in tqdm(loader, desc="Processing Features"):
        edge_index, _, size = adjs.to(device)  # Adjusted to unpack adjs correctly
        x = data.x[n_id].to(device)
        x_propagated = appnp(x, edge_index).cpu().numpy()

        # Only save features for nodes that haven't been processed yet
        for idx, node_id in enumerate(n_id.cpu().numpy()):
            if node_id not in processed_nodes:
                all_features[node_id] = x_propagated[idx]
                processed_nodes.add(node_id)

    with h5py.File(save_path, 'w') as hf:
        hf.create_dataset('features', data=all_features)


def load_appnp_features(data, load_path):
    with h5py.File(load_path, 'r') as hf:
        all_features = hf['features'][:]
    data.x = torch.from_numpy(all_features)
'''
